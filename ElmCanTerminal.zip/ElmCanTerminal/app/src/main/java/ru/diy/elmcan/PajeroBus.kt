package ru.diy.elmcan

import java.util.Locale

/**
 * Широковещательные кадры шины OBD Mitsubishi Pajero Sport II (KH, 4M41).
 * Источники: igkov/bcomp11 и igkov/ecu-emulator (кадры и периоды),
 * fabioseidl/mitsubish-pajero-dashboard (проверка на KH8W 4M41).
 */
object PajeroBus {

    class Field(val key: String, val title: String, val value: String, val unit: String = "")

    class FrameInfo(val id: Int, val group: String, val name: String, val period: String, val confirmed: Boolean)

    val GROUPS = listOf("Двигатель", "АКПП", "Шасси", "Кузов", "Климат", "Прочее")

    val known: Map<Int, FrameInfo> = listOf(
        FrameInfo(0x308, "Двигатель", "Обороты", "20 мс", true),
        FrameInfo(0x608, "Двигатель", "ОЖ и расход топлива", "100 мс", true),
        FrameInfo(0x212, "Двигатель", "Двигатель (не расшифрован)", "20 мс", false),
        FrameInfo(0x312, "Двигатель", "Педаль газа? (не подтверждено)", "20 мс", false),
        FrameInfo(0x218, "АКПП", "Передача", "20 мс", true),
        FrameInfo(0x215, "Шасси", "Скорость и счётчик пути", "20 мс", true),
        FrameInfo(0x236, "Шасси", "Датчик угла руля", "10 мс", false),
        FrameInfo(0x325, "Шасси", "(не расшифрован)", "20 мс", false),
        FrameInfo(0x424, "Кузов", "ETACS: свет, поворотники, двери", "40 мс", true),
        FrameInfo(0x415, "Кузов", "(не расшифрован)", "100 мс", false),
        FrameInfo(0x447, "Климат", "(не расшифрован)", "50 мс", false),
        FrameInfo(0x445, "Климат", "Климат-контроль", "40 мс", true),
        FrameInfo(0x101, "Прочее", "(не расшифрован)", "100 мс", false),
    ).associateBy { it.id }

    /** Плитки «Шина» на экране приборов, в порядке показа. */
    val dashKeys: List<Pair<String, String>> = listOf(
        "bus.rpm" to "Обороты, об/мин",
        "bus.speed" to "Скорость, км/ч",
        "bus.gear" to "Передача",
        "bus.coolant" to "ОЖ, °C",
        "bus.fuel_lh" to "Расход, л/ч",
        "bus.fuel_100" to "Расход, л/100 км",
        "bus.lights" to "Свет",
        "bus.doors" to "Двери",
        "bus.climate" to "Климат",
        "bus.steer" to "Руль (сырое)",
    )

    /** Какие ID слушать по очереди в режиме «Шина» на экране приборов. */
    val dashScanIds = listOf(0x308, 0x215, 0x218, 0x608, 0x424, 0x445, 0x236)

    /** Плотность дизтоплива, г/л — для перевода мг/с в л/ч. */
    private const val DIESEL_DENSITY_G_L = 835.0

    private fun f1(v: Double) = String.format(Locale.US, "%.1f", v)

    fun gearName(code: Int): String = when (code) {
        0x0 -> "N"
        0x1 -> "1/D"
        in 2..5 -> code.toString()
        0xB -> "R"
        0xD -> "P"
        else -> "?" + Integer.toHexString(code).uppercase()
    }

    private fun climateTemp(raw: Int): String = when {
        raw <= 50 -> "LO"
        raw >= 98 -> "HI"
        raw == 96 -> "30"
        raw in 64..82 -> f1(20 + (raw - 64) / 2.0)
        else -> "raw $raw"
    }

    private fun on(b: Boolean) = if (b) "вкл" else "выкл"

    /** Расшифровка кадра. Пустой список — ID неизвестен или данных мало. */
    fun decode(id: Int, d: IntArray): List<Field> {
        val out = ArrayList<Field>()
        fun u16(i: Int) = d[i] * 256 + d[i + 1]
        when (id) {
            0x308 -> if (d.size >= 3) out.add(Field("bus.rpm", "Обороты", u16(1).toString(), "об/мин"))
            0x608 -> if (d.size >= 7) {
                val raw = u16(5)
                val lh = raw * 3.6 / DIESEL_DENSITY_G_L
                out.add(Field("bus.coolant", "ОЖ", (d[0] - 40).toString(), "°C"))
                out.add(Field("bus.fuel_raw", "Впрыск", raw.toString(), "мг/с"))
                out.add(Field("bus.fuel_lh", "Расход", f1(lh), "л/ч"))
            }
            0x218 -> if (d.size >= 3) {
                val cur = gearName(d[2] and 0x0F)
                val tgt = gearName(d[2] shr 4)
                out.add(Field("bus.gear", "Передача", if (cur == tgt) cur else "$cur→$tgt"))
            }
            0x215 -> if (d.size >= 4) {
                out.add(Field("bus.speed", "Скорость", f1(u16(0) / 128.0), "км/ч"))
                out.add(Field("bus.dist", "Счётчик пути", u16(2).toString(), "имп."))
            }
            0x236 -> if (d.size >= 2) {
                out.add(Field("bus.steer", "Руль (D0D1 − 0x1000)", (u16(0) - 0x1000).toString()))
            }
            0x424 -> if (d.size >= 3) {
                val lights = ArrayList<String>()
                if (d[1] and 0x20 != 0) lights.add("ближний")
                if (d[1] and 0x04 != 0) lights.add("дальний")
                if (d[1] and 0x02 != 0) lights.add("◀")
                if (d[1] and 0x01 != 0) lights.add("▶")
                if (d[0] and 0x04 != 0) lights.add("габар.?")
                val doors = ArrayList<String>()
                if (d[2] and 0x02 != 0) doors.add("водит.")
                if (d[2] and 0x01 != 0) doors.add("другие")
                out.add(Field("bus.lights", "Свет", lights.joinToString(" ").ifEmpty { "выкл" }))
                out.add(Field("bus.doors", "Открыты двери", doors.joinToString(", ").ifEmpty { "закрыты" }))
            }
            0x445 -> if (d.size >= 6) {
                val vents = ArrayList<String>()
                if (d[5] and 0x02 != 0) vents.add("лицо")
                if (d[5] and 0x04 != 0) vents.add("ноги")
                if (d[5] and 0x08 != 0) vents.add("стекло")
                val fan = d[5] shr 4
                val t = climateTemp(d[0])
                out.add(Field("bus.climate", "Климат",
                    "$t° · вент.$fan" + (if (d[3] and 0x08 != 0) " · A/C" else "") +
                        (if (d[3] and 0x02 != 0) " · рецирк." else "")))
                out.add(Field("bus.ac_temp", "Уставка", t, "°C"))
                out.add(Field("bus.ac_fan", "Вентилятор", fan.toString()))
                out.add(Field("bus.ac_on", "A/C", on(d[3] and 0x08 != 0)))
                out.add(Field("bus.ac_recirc", "Рециркуляция", on(d[3] and 0x02 != 0)))
                out.add(Field("bus.ac_vents", "Обдув", vents.joinToString(", ").ifEmpty { "—" }))
            }
        }
        return out
    }

    /** Значения, которые считаются из нескольких кадров сразу. */
    fun derived(values: Map<String, String>): List<Field> {
        val lh = values["bus.fuel_lh"]?.toDoubleOrNull() ?: return emptyList()
        val v = values["bus.speed"]?.toDoubleOrNull() ?: return emptyList()
        if (v < 5) return listOf(Field("bus.fuel_100", "Расход", "стоим", ""))
        return listOf(Field("bus.fuel_100", "Расход", f1(lh * 100 / v), "л/100 км"))
    }

    /** Готовые фильтры для сниффера: подпись → строка фильтра (ID или ID/маска). */
    val filterPresets: List<Pair<String, String>> = listOf(
        "Все" to "",
        "Скорость+АКПП" to "210/7F0",
        "Обороты" to "308",
        "Топливо/ОЖ" to "608",
        "Кузов+климат" to "400/780",
        "Руль" to "236",
    )
}
