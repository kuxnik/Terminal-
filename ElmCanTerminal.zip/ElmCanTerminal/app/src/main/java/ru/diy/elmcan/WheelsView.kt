package ru.diy.elmcan

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.TypedValue
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/**
 * Схема машины сверху: четыре колеса, у каждого — скорость и стрелка отклонения от среднего.
 * Стрелка вверх — колесо крутится быстрее среднего, вниз — медленнее; длина пропорциональна
 * разнице в процентах (полная стрелка — 10 %). Колесо с нулём при движущейся машине — красное.
 * Позиции: 0 — перед-лево, 1 — перед-право, 2 — зад-лево, 3 — зад-право.
 */
class WheelsView(context: Context) : View(context) {

    /** Скорость колёс по позициям; null — нет данных. */
    var speeds: Array<Double?> = arrayOfNulls(4)
        set(v) { field = v; invalidate() }

    /** Подпись, какой байт таблицы 21 20 показан на позиции, напр. «D1». */
    var sourceLabels: Array<String> = arrayOf("", "", "", "")
        set(v) { field = v; invalidate() }

    private val bg = Color.rgb(16, 17, 19)
    private val surface = Color.rgb(36, 38, 42)
    private val line = Color.rgb(90, 95, 102)
    private val text = Color.rgb(232, 234, 237)
    private val muted = Color.rgb(140, 145, 152)
    private val faster = Color.rgb(129, 199, 132)
    private val slower = Color.rgb(255, 167, 38)
    private val bad = Color.rgb(239, 83, 80)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val names = arrayOf("Перед-лево", "Перед-право", "Зад-лево", "Зад-право")

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(bg)
        val w = width.toFloat()
        val h = height.toFloat()

        val known = speeds.filterNotNull()
        val mean = if (known.isEmpty()) 0.0 else known.average()
        val moving = mean >= 2.0

        // Кузов
        val bodyH = h * 0.78f
        val bodyW = min(w * 0.22f, bodyH * 0.48f)
        val cx = w / 2
        val top = h * 0.11f
        val body = RectF(cx - bodyW / 2, top, cx + bodyW / 2, top + bodyH)
        p.style = Paint.Style.FILL; p.color = surface
        c.drawRoundRect(body, dp(26f), dp(26f), p)
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(2f); p.color = line
        c.drawRoundRect(body, dp(26f), dp(26f), p)
        // лобовое стекло — указывает, где перед
        val glass = RectF(body.left + bodyW * 0.15f, top + bodyH * 0.18f, body.right - bodyW * 0.15f, top + bodyH * 0.30f)
        c.drawRoundRect(glass, dp(8f), dp(8f), p)
        p.style = Paint.Style.FILL; p.color = muted; p.textSize = sp(14f); p.textAlign = Paint.Align.CENTER
        c.drawText("ПЕРЕД", cx, top - dp(10f), p)

        // Колёса
        val wheelW = bodyW * 0.28f
        val wheelH = bodyH * 0.17f
        val ys = floatArrayOf(top + bodyH * 0.12f, top + bodyH * 0.71f)   // перед, зад
        for (pos in 0..3) {
            val left = pos % 2 == 0
            val y = ys[pos / 2]
            val x = if (left) body.left - wheelW * 0.55f else body.right - wheelW * 0.45f
            val r = RectF(x, y, x + wheelW, y + wheelH)
            val v = speeds[pos]
            val noSignal = v != null && moving && v < 0.5
            p.style = Paint.Style.FILL
            p.color = when { noSignal -> bad; v == null -> line; else -> text }
            c.drawRoundRect(r, dp(6f), dp(6f), p)

            // Подписи и стрелка — снаружи от колеса
            val tx = if (left) r.left - dp(36f) else r.right + dp(36f)
            p.textAlign = if (left) Paint.Align.RIGHT else Paint.Align.LEFT
            p.color = muted; p.textSize = sp(13f)
            c.drawText(names[pos] + (if (sourceLabels[pos].isNotEmpty()) " · " + sourceLabels[pos] else ""),
                tx, y + sp(12f), p)
            p.color = if (noSignal) bad else text; p.textSize = sp(40f)
            c.drawText(v?.let { fmt(it, 0) } ?: "—", tx, y + sp(12f) + sp(42f), p)

            if (v != null && moving) {
                val deltaPct = (v - mean) / mean * 100
                p.textSize = sp(15f)
                p.color = if (noSignal) bad else if (abs(deltaPct) < 2) muted else if (deltaPct > 0) faster else slower
                val label = if (noSignal) "нет сигнала" else (if (deltaPct >= 0) "+" else "") + fmt(deltaPct, 1) + " %"
                c.drawText(label, tx, y + sp(12f) + sp(42f) + sp(22f), p)
                if (!noSignal) drawArrow(c, if (left) r.left - dp(4f) else r.right + dp(4f), y + wheelH / 2,
                    deltaPct, wheelH * 1.1f, left)
            }
        }

        // Итоги внизу
        p.textAlign = Paint.Align.CENTER; p.textSize = sp(15f)
        val bottom = h - dp(14f)
        if (!moving) {
            p.color = muted
            c.drawText(if (known.isEmpty()) "Нажмите «Старт»" else "Стоим", cx, bottom, p)
        } else {
            fun side(a: Int, b: Int) = listOfNotNull(speeds[a], speeds[b]).let { if (it.isEmpty()) null else it.average() }
            val l = side(0, 2); val rr = side(1, 3); val f = side(0, 1); val bk = side(2, 3)
            val parts = ArrayList<String>()
            if (l != null && rr != null) parts.add("Право − лево: " + signed((rr - l) / mean * 100) + " %")
            if (f != null && bk != null) parts.add("Перед − зад: " + signed((f - bk) / mean * 100) + " %")
            parts.add("Среднее: " + fmt(mean, 1))
            p.color = text
            c.drawText(parts.joinToString("     "), cx, bottom, p)
        }
    }

    /** Вертикальная стрелка у колеса: вверх — быстрее среднего, вниз — медленнее. */
    private fun drawArrow(c: Canvas, x: Float, cy: Float, deltaPct: Double, maxLen: Float, left: Boolean) {
        if (abs(deltaPct) < 2) return
        val len = (min(abs(deltaPct), 10.0) / 10.0 * maxLen).toFloat().coerceAtLeast(maxLen * 0.25f)
        val up = deltaPct > 0
        val ax = if (left) x - dp(12f) else x + dp(12f)
        val y1 = cy + (if (up) len / 2 else -len / 2)
        val y2 = cy - (if (up) len / 2 else -len / 2)
        p.color = if (up) faster else slower
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(4f)
        c.drawLine(ax, y1, ax, y2, p)
        val head = dp(10f)
        val path = Path().apply {
            moveTo(ax, y2 - (if (up) head else -head) * 0.4f)
            lineTo(ax - head, y2 + (if (up) head else -head))
            lineTo(ax + head, y2 + (if (up) head else -head))
            close()
        }
        p.style = Paint.Style.FILL
        c.drawPath(path, p)
    }

    private fun fmt(v: Double, d: Int) = String.format(Locale.US, "%.${d}f", v)
    private fun signed(v: Double) = (if (v >= 0) "+" else "") + fmt(v, 1)
}
