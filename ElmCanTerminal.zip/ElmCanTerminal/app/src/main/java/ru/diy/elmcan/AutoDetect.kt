package ru.diy.elmcan

import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Автопоиск: запись таблиц 21 xx всех блоков вместе с эталонными параметрами OBD-II
 * (обороты, скорость, ОЖ, …) и метками пользователя (P/R/N/D, кондиционер, фары…),
 * затем анализ:
 *  1) корреляция каждого байта и каждой пары байтов с эталонами → «этот байт = обороты · k + b»;
 *  2) совпадение с метками → «этот байт принимает своё значение на каждой метке».
 * Только чтение. Все методы потокобезопасны.
 */
class AutoDetect {

    class Sample(val t: Long, val data: IntArray)

    private val lock = Any()
    private val tables = LinkedHashMap<String, MutableList<Sample>>()        // "7E0:214D" → отсчёты
    private val refs = LinkedHashMap<String, MutableList<Pair<Long, Double>>>() // "Обороты" → (t, значение)
    private val marks = ArrayList<Pair<Long, String>>()
    var startTime = 0L
        private set

    fun clear() = synchronized(lock) {
        tables.clear(); refs.clear(); marks.clear(); startTime = System.currentTimeMillis()
    }

    fun addTable(id: String, t: Long, data: IntArray) = synchronized(lock) {
        if (startTime == 0L) startTime = t
        tables.getOrPut(id) { ArrayList() }.add(Sample(t, data))
    }

    fun addRef(name: String, t: Long, v: Double) = synchronized(lock) {
        if (startTime == 0L) startTime = t
        refs.getOrPut(name) { ArrayList() }.add(t to v)
    }

    fun addMark(t: Long, label: String) = synchronized(lock) { marks.add(t to label) }

    fun summary(): String = synchronized(lock) {
        val samples = tables.values.sumOf { it.size }
        "Таблиц: ${tables.size}, отсчётов: $samples, эталонов: ${refs.values.sumOf { it.size }}, меток: ${marks.size}"
    }

    fun csv(): String = synchronized(lock) {
        val sb = StringBuilder("time_ms;kind;id;value\n")
        val rows = ArrayList<Triple<Long, String, String>>()
        for ((id, list) in tables) for (s in list)
            rows.add(Triple(s.t, "table;$id", s.data.joinToString(" ") { String.format("%02X", it) }))
        for ((name, list) in refs) for ((t, v) in list) rows.add(Triple(t, "ref;$name", fmt(v)))
        for ((t, l) in marks) rows.add(Triple(t, "mark;$l", ""))
        rows.sortBy { it.first }
        for ((t, k, v) in rows) sb.append(t - startTime).append(';').append(k).append(';').append(v).append('\n')
        sb.toString()
    }

    // ---------------- анализ ----------------

    private class Cand(val table: String, val pos: String, val values: List<Pair<Long, Double>>)

    private fun candidates(id: String, list: List<Sample>): List<Cand> {
        val maxLen = list.maxOfOrNull { it.data.size } ?: 0
        val out = ArrayList<Cand>()
        for (i in 0 until maxLen) {
            out.add(Cand(id, "байт $i", list.filter { it.data.size > i }.map { it.t to it.data[i].toDouble() }))
            // знаковый вариант (−128…127) — для коррекций и т. п.
            out.add(Cand(id, "байт $i (знак.)", list.filter { it.data.size > i }.map {
                val v = it.data[i]; it.t to (if (v >= 128) v - 256 else v).toDouble()
            }))
        }
        for (i in 0 until maxLen - 1) {
            out.add(Cand(id, "байты $i-${i + 1}", list.filter { it.data.size > i + 1 }.map {
                it.t to (it.data[i] * 256 + it.data[i + 1]).toDouble()
            }))
        }
        return out
    }

    /** Значение эталона, ближайшее по времени (не дальше maxDt). */
    private fun refAt(list: List<Pair<Long, Double>>, t: Long, maxDt: Long = 2500): Double? {
        var best: Pair<Long, Double>? = null
        var bestDt = Long.MAX_VALUE
        for (p in list) {
            val dt = abs(p.first - t)
            if (dt < bestDt) { bestDt = dt; best = p }
        }
        return if (best != null && bestDt <= maxDt) best.second else null
    }

    private class Hit(val ref: String, val table: String, val pos: String, val r: Double,
                      val a: Double, val b: Double, val n: Int)

    fun analyze(): String {
        val tablesCopy: Map<String, List<Sample>>
        val refsCopy: Map<String, List<Pair<Long, Double>>>
        val marksCopy: List<Pair<Long, String>>
        synchronized(lock) {
            tablesCopy = tables.mapValues { it.value.toList() }
            refsCopy = refs.mapValues { it.value.toList() }
            marksCopy = marks.toList()
        }
        val sb = StringBuilder()
        sb.append("АВТОПОИСК — результаты\n")
        sb.append("Таблиц: ${tablesCopy.size}, отсчётов: ${tablesCopy.values.sumOf { it.size }}, меток: ${marksCopy.size}\n\n")

        val allCands = tablesCopy.flatMap { (id, list) -> candidates(id, list) }
            .filter { c -> c.values.map { it.second }.distinct().size >= 3 }   // только меняющиеся

        // 1) корреляция с эталонами
        sb.append("━━ Совпадения с эталонами OBD ━━\n")
        val hits = ArrayList<Hit>()
        for ((refName, refList) in refsCopy) {
            val refVals = refList.map { it.second }
            if (refVals.distinct().size < 3) continue      // эталон не менялся — сравнивать не с чем
            for (c in allCands) {
                val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
                for ((t, x) in c.values) { val y = refAt(refList, t) ?: continue; xs.add(x); ys.add(y) }
                if (xs.size < 8) continue
                val r = pearson(xs, ys) ?: continue
                if (abs(r) < 0.95) continue
                val (a, b) = fit(xs, ys)
                hits.add(Hit(refName, c.table, c.pos, r, a, b, xs.size))
            }
        }
        if (hits.isEmpty()) {
            sb.append("Нет. Нужно, чтобы эталоны менялись: перегазовки (обороты), поездка (скорость), прогрев (ОЖ).\n")
        } else {
            for ((ref, list) in hits.groupBy { it.ref }) {
                sb.append("\n$ref:\n")
                // одна лучшая позиция на таблицу, всего не больше 6
                list.sortedByDescending { abs(it.r) }
                    .distinctBy { it.table + it.pos.substringBefore(" (") }
                    .take(6)
                    .forEach { h ->
                        sb.append(String.format(Locale.US, "  %s %s  r=%.3f  →  %s ≈ %s·x %s %s  (n=%d)\n",
                            h.table, h.pos, h.r, ref, fmt(h.a), if (h.b < 0) "−" else "+", fmt(abs(h.b)), h.n))
                    }
            }
        }

        // 2) совпадение с метками
        sb.append("\n━━ Совпадения с метками ━━\n")
        if (marksCopy.size < 2) {
            sb.append("Меток меньше двух. Нажимайте кнопки меток в момент действия (P, R, N, D, A/C…).\n")
        } else {
            val endT = System.currentTimeMillis()
            val segs = marksCopy.mapIndexed { i, (t, l) ->
                Triple(l, t + 1500, if (i + 1 < marksCopy.size) marksCopy[i + 1].first else endT)
            }
            val labels = segs.map { it.first }.distinct()
            data class MarkHit(val table: String, val pos: String, val map: Map<String, Int>, val score: Int)
            val mhits = ArrayList<MarkHit>()
            for ((id, list) in tablesCopy) {
                val maxLen = list.maxOfOrNull { it.data.size } ?: 0
                for (i in 0 until maxLen) {
                    val perLabel = HashMap<String, MutableSet<Int>>()
                    var ok = true
                    for ((l, from, to) in segs) {
                        val vals = list.filter { it.t in from until to && it.data.size > i }.map { it.data[i] }
                        if (vals.isEmpty()) continue
                        val set = perLabel.getOrPut(l) { HashSet() }
                        set.addAll(vals)
                        if (set.size > 1) { ok = false; break }   // внутри одной метки значение плавает
                    }
                    if (!ok || perLabel.size < 2) continue
                    val distinct = perLabel.values.map { it.first() }.distinct().size
                    if (distinct < 2) continue
                    mhits.add(MarkHit(id, "байт $i", perLabel.mapValues { it.value.first() }, distinct * 10 + perLabel.size))
                }
            }
            if (mhits.isEmpty()) {
                sb.append("Нет байтов, которые стабильно меняются вместе с метками.\n")
            } else {
                mhits.sortedByDescending { it.score }.take(15).forEach { h ->
                    sb.append("  ${h.table} ${h.pos}: ")
                    sb.append(labels.filter { it in h.map }.joinToString("  ") { "$it=" + String.format("%02X", h.map[it]) })
                    sb.append('\n')
                }
                sb.append("(Сверху — байты, где у разных меток больше всего разных значений.)\n")
            }
        }

        // 3) просто активные таблицы
        sb.append("\n━━ Меняющиеся таблицы ━━\n")
        tablesCopy.forEach { (id, list) ->
            if (list.size < 2) return@forEach
            val maxLen = list.maxOf { it.data.size }
            val changing = (0 until maxLen).filter { i -> list.mapNotNull { it.data.getOrNull(i) }.distinct().size > 1 }
            if (changing.isNotEmpty()) sb.append("  $id: меняются байты ${changing.joinToString(",")}\n")
        }
        return sb.toString()
    }

    private fun pearson(x: List<Double>, y: List<Double>): Double? {
        val n = x.size
        val mx = x.average(); val my = y.average()
        var sxy = 0.0; var sxx = 0.0; var syy = 0.0
        for (i in 0 until n) {
            val dx = x[i] - mx; val dy = y[i] - my
            sxy += dx * dy; sxx += dx * dx; syy += dy * dy
        }
        if (sxx <= 0.0 || syy <= 0.0) return null
        return sxy / sqrt(sxx * syy)
    }

    /** Наименьшие квадраты: y = a·x + b. */
    private fun fit(x: List<Double>, y: List<Double>): Pair<Double, Double> {
        val mx = x.average(); val my = y.average()
        var sxy = 0.0; var sxx = 0.0
        for (i in x.indices) { sxy += (x[i] - mx) * (y[i] - my); sxx += (x[i] - mx) * (x[i] - mx) }
        val a = if (sxx == 0.0) 0.0 else sxy / sxx
        return a to (my - a * mx)
    }

    private fun fmt(v: Double): String =
        if (abs(v) >= 100) String.format(Locale.US, "%.0f", v)
        else if (abs(v) >= 1) String.format(Locale.US, "%.2f", v)
        else String.format(Locale.US, "%.4f", v)
}
