package ru.diy.elmcan

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), ElmClient.Listener {

    private val ui = Handler(Looper.getMainLooper())
    private val client = ElmClient(this)
    private val sniffer = SnifferStore()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    // верхняя панель
    private lateinit var hostEdit: EditText
    private lateinit var portEdit: EditText
    private lateinit var protoEdit: EditText
    private lateinit var connectBtn: Button
    private lateinit var statusText: TextView

    // вкладки
    private val tabButtons = ArrayList<Button>()
    private lateinit var content: FrameLayout
    private lateinit var terminalView: View
    private lateinit var snifferView: View
    private lateinit var dashView: View
    private var currentTab = 0

    // терминал
    private lateinit var termOut: TextView
    private lateinit var termScroll: ScrollView
    private lateinit var termInput: EditText
    private val termScreen = StringBuilder()
    private val termLog = StringBuilder()

    // сниффер
    private lateinit var filterEdit: EditText
    private lateinit var snifStartBtn: Button
    private lateinit var snifModeBtn: Button
    private lateinit var snifInfo: TextView
    private lateinit var snifOut: TextView
    private var snifRunning = false
    private var snifView = 1   // 0 — таблица, 1 — расшифровка, 2 — поток
    private val snifViewNames = listOf("Вид: таблица", "Вид: расшифровка", "Вид: поток")

    // приборы
    private lateinit var dashStartBtn: Button
    private lateinit var busStartBtn: Button
    private val dashValues = HashMap<String, TextView>()
    private var dashRunning = false
    private var busRunning = false

    private var pendingSave: String? = null

    // ============================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18, 18, 18))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(buildConnectionBar())
        root.addView(buildTabBar())
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        terminalView = buildTerminal()
        snifferView = buildSniffer()
        dashView = buildDashboard()
        content.addView(terminalView)
        content.addView(snifferView)
        content.addView(dashView)

        setContentView(root)
        selectTab(0)
        ui.post(refreshTask)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        client.disconnect()
        super.onDestroy()
    }

    // ------------------------------------------------------------ верх

    private fun buildConnectionBar(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        hostEdit = edit(prefs.getString("host", "192.168.0.10")!!, "IP адаптера")
        portEdit = edit(prefs.getString("port", "35000")!!, "порт").apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        protoEdit = edit(prefs.getString("proto", "6")!!, "прот.")
        connectBtn = button("Подключить") { toggleConnection() }
        row.addView(hostEdit, LinearLayout.LayoutParams(0, WRAP, 3f))
        row.addView(portEdit, LinearLayout.LayoutParams(0, WRAP, 1.6f))
        row.addView(protoEdit, LinearLayout.LayoutParams(0, WRAP, 0.9f))
        row.addView(connectBtn, LinearLayout.LayoutParams(WRAP, WRAP))
        box.addView(row)
        statusText = text("Не подключено. Подключите телефон к Wi-Fi сети адаптера.", 13f).apply {
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), 0, 0, dp(4))
        }
        box.addView(statusText)
        return box
    }

    private fun toggleConnection() {
        if (client.connected) {
            stopAll()
            client.disconnect()
            return
        }
        val host = hostEdit.text.toString().trim()
        val port = portEdit.text.toString().trim().toIntOrNull() ?: 35000
        val proto = protoEdit.text.toString().trim().ifEmpty { "6" }
        prefs.edit().putString("host", host).putString("port", port.toString())
            .putString("proto", proto).apply()
        client.connect(applicationContext, host, port, proto)
    }

    private fun buildTabBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Терминал", "Сниффер", "Приборы").forEachIndexed { i, name ->
            val b = button(name) { selectTab(i) }
            tabButtons.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return row
    }

    private fun selectTab(i: Int) {
        if (i != currentTab) stopAll()
        currentTab = i
        terminalView.visibility = if (i == 0) View.VISIBLE else View.GONE
        snifferView.visibility = if (i == 1) View.VISIBLE else View.GONE
        dashView.visibility = if (i == 2) View.VISIBLE else View.GONE
        tabButtons.forEachIndexed { idx, b -> b.alpha = if (idx == i) 1f else 0.5f }
    }

    private fun stopAll() {
        if (snifRunning) { client.stopMonitor(); snifRunning = false; snifStartBtn.text = "Старт" }
        if (dashRunning) { client.stopPolling(); dashRunning = false; dashStartBtn.text = "Опрос ЭБУ" }
        if (busRunning) { client.stopPolling(); busRunning = false; busStartBtn.text = "Слушать шину" }
    }

    // ------------------------------------------------------------ терминал

    private fun buildTerminal(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        termOut = mono(13f)
        termOut.setTextIsSelectable(true)
        termScroll = ScrollView(this).apply { addView(termOut) }
        box.addView(termScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // быстрые команды
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "ATI", "ATRV", "ATDP", "0100", "010C", "0105", "03", "07",
            "ATSH7E1", "2102", "ATSH7E0", "2103", "ATSH7DF", "0902", "ATZ", "ATPC",
        ).forEach { c -> quick.addView(button(c) { sendTerm(c) }) }
        box.addView(HorizontalScrollView(this).apply { addView(quick) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        termInput = edit("", "команда, напр. 2101 или ATSH7E0").apply {
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            typeface = Typeface.MONOSPACE
            setOnEditorActionListener { _, actionId, ev ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
                ) { sendFromInput(); true } else false
            }
        }
        inputRow.addView(termInput, LinearLayout.LayoutParams(0, WRAP, 1f))
        inputRow.addView(button("➤") { sendFromInput() })
        box.addView(inputRow)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(button("Очистить") {
            termScreen.setLength(0); termOut.text = ""
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        tools.addView(button("Сохранить лог") {
            saveText("terminal", "txt", termLog.toString())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(tools)
        return box
    }

    private fun sendFromInput() {
        val c = termInput.text.toString().trim()
        if (c.isEmpty()) return
        termInput.setText("")
        sendTerm(c)
    }

    private fun sendTerm(cmd: String) {
        stopAll()
        client.send(cmd)
    }

    private fun appendTerm(s: String) {
        val stamped = time() + "  " + s.replace("\n", "\n              ") + "\n"
        termLog.append(stamped)
        termScreen.append(stamped)
        if (termScreen.length > 60_000) termScreen.delete(0, termScreen.length - 40_000)
        termOut.text = termScreen
        termScroll.post { termScroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------ сниффер

    private fun buildSniffer(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        filterEdit = edit("", "фильтр: 308 или 210/7F0").apply { typeface = Typeface.MONOSPACE }
        snifStartBtn = button("Старт") { toggleSniffer() }
        row.addView(filterEdit, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(snifStartBtn)
        box.addView(row)

        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        PajeroBus.filterPresets.forEach { (label, f) ->
            presets.addView(button(label) {
                filterEdit.setText(f)
                if (snifRunning) { toggleSniffer(); toggleSniffer() }
            })
        }
        box.addView(HorizontalScrollView(this).apply { addView(presets) })

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        snifModeBtn = button(snifViewNames[snifView]) {
            snifView = (snifView + 1) % 3
            snifModeBtn.text = snifViewNames[snifView]
        }
        row2.addView(snifModeBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(button("Очистить") { sniffer.clear() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(button("CSV") {
            saveText("can_log", "csv", sniffer.exportCsv())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(button(".trc") {
            saveText("can_trace", "trc", sniffer.exportTrc())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(row2)

        snifInfo = text("", 12f).apply { setTextColor(Color.LTGRAY) }
        box.addView(snifInfo)

        snifOut = mono(11.5f)
        snifOut.setHorizontallyScrolling(true)
        val hs = HorizontalScrollView(this).apply { addView(snifOut) }
        box.addView(ScrollView(this).apply { addView(hs) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    private fun toggleSniffer() {
        if (snifRunning) {
            client.stopMonitor()
            snifRunning = false
            snifStartBtn.text = "Старт"
            return
        }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        val f = filterEdit.text.toString().trim()
        if (f.isNotEmpty() && !Regex("^([0-9A-Fa-f]{3}|[0-9A-Fa-f]{8})(/([0-9A-Fa-f]{3}|[0-9A-Fa-f]{8}))?$").matches(f)) {
            toast("Фильтр: ID (308) или ID/маска (210/7F0); 3 hex-символа для 11 бит, 8 — для 29 бит"); return
        }
        client.startMonitor(f)
        snifRunning = true
        snifStartBtn.text = "Стоп"
    }

    private var lastFrames = 0L
    private var lastRateTime = 0L
    private var rate = 0.0

    private val refreshTask = object : Runnable {
        override fun run() {
            if (currentTab == 1) {
                val now = System.currentTimeMillis()
                val total = sniffer.totalFrames
                if (now - lastRateTime >= 1000) {
                    if (lastRateTime != 0L) rate = (total - lastFrames) * 1000.0 / (now - lastRateTime)
                    lastFrames = total; lastRateTime = now
                }
                snifInfo.text = String.format(
                    Locale.US, "Кадров: %d   ID: %d   %.0f кадр/с   служебных строк: %d",
                    total, sniffer.idCount(), rate, sniffer.otherMessages
                )
                snifOut.text = when (snifView) {
                    0 -> sniffer.buildTable()
                    1 -> sniffer.buildDecoded()
                    else -> sniffer.buildRaw()
                }
            }
            if (currentTab == 2 && busRunning) {
                val vals = sniffer.decodedValues()
                for ((key, _) in PajeroBus.dashKeys) dashValues[key]?.text = vals[key] ?: "—"
            }
            ui.postDelayed(this, 300)
        }
    }

    // ------------------------------------------------------------ приборы

    private fun buildDashboard(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        dashStartBtn = button("Опрос ЭБУ") { toggleDash() }
        busStartBtn = button("Слушать шину") { toggleBus() }
        btns.addView(dashStartBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        btns.addView(busStartBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(btns)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(sectionTitle("Шина — без запросов (Pajero Sport II)"))
        addTiles(content, PajeroBus.dashKeys)
        content.addView(sectionTitle("Опрос ЭБУ — OBD-II и режим 21"))
        addTiles(content, Obd.pollList.flatMap { p -> p.outputs.map { it.key to "${it.title}, ${it.unit}" } })
        content.addView(text(
            "«Слушать шину» — данные из кадров, которые машина передаёт сама (обороты 0x308, скорость 0x215, " +
                "передача 0x218, ОЖ и расход 0x608, свет и двери 0x424, климат 0x445). " +
                "«Опрос ЭБУ» — запросы: стандартный OBD-II, АКПП 7E1 21 02 (ATF, обороты валов), " +
                "пробег 7E0 21 03. «нет» — ЭБУ не отвечает на запрос. Режимы работают по очереди: " +
                "ELM327 умеет только одно дело за раз.",
            12f
        ).apply { setTextColor(Color.GRAY); setPadding(dp(4), dp(8), dp(4), dp(8)) })
        box.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    private fun sectionTitle(s: String) = text(s, 14f).apply {
        setTextColor(Color.rgb(129, 199, 132))
        setPadding(dp(4), dp(10), dp(4), dp(2))
    }

    private fun addTiles(parent: LinearLayout, tiles: List<Pair<String, String>>) {
        var row: LinearLayout? = null
        tiles.forEachIndexed { i, (key, label) ->
            if (i % 2 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                parent.addView(row)
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.rgb(38, 38, 38))
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }
            val value = text("—", 26f).apply {
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                isSingleLine = true
            }
            card.addView(value)
            card.addView(text(label, 12f).apply { setTextColor(Color.LTGRAY) })
            dashValues[key] = value
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            row!!.addView(card, lp)
        }
        if (tiles.size % 2 == 1) row!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    private fun toggleDash() {
        if (dashRunning) {
            client.stopPolling()
            dashRunning = false
            dashStartBtn.text = "Опрос ЭБУ"
            return
        }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startPolling(Obd.pollList)
        dashRunning = true
        dashStartBtn.text = "Стоп опроса"
    }

    private fun toggleBus() {
        if (busRunning) {
            client.stopPolling()
            busRunning = false
            busStartBtn.text = "Слушать шину"
            return
        }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startBusScan(PajeroBus.dashScanIds)
        busRunning = true
        busStartBtn.text = "Стоп шины"
    }

    // ------------------------------------------------------------ ElmClient.Listener

    override fun onStatus(connected: Boolean, text: String) = ui.post {
        statusText.text = text
        statusText.setTextColor(if (connected) Color.rgb(129, 199, 132) else Color.LTGRAY)
        connectBtn.text = if (connected) "Отключить" else "Подключить"
        if (!connected) stopAll()
        appendTerm("// $text")
    }.let { }

    override fun onTraffic(tx: Boolean, text: String) = ui.post {
        appendTerm((if (tx) "> " else "< ") + text)
    }.let { }

    override fun onMonitorLine(line: String) = sniffer.onLine(line)

    override fun onPidValue(key: String, value: String?) = ui.post {
        dashValues[key]?.text = value ?: "—"
    }.let { }

    // ------------------------------------------------------------ сохранение (SAF)

    private fun saveText(prefix: String, ext: String, data: String) {
        pendingSave = data
        val name = prefix + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "." + ext
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = when (ext) { "csv" -> "text/csv"; "txt" -> "text/plain"; else -> "application/octet-stream" }
            putExtra(Intent.EXTRA_TITLE, name)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQ_SAVE)
    }

    @Deprecated("Activity API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE) return
        val uri = data?.data
        val text = pendingSave
        pendingSave = null
        if (resultCode != RESULT_OK || uri == null || text == null) return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            toast("Сохранено")
        } catch (e: Exception) {
            toast("Не удалось сохранить: ${e.message}")
        }
    }

    // ------------------------------------------------------------ помощники UI

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun text(s: String, sp: Float) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    }

    private fun mono(sp: Float) = TextView(this).apply {
        typeface = Typeface.MONOSPACE
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(Color.rgb(220, 220, 220))
        setPadding(dp(4), dp(4), dp(4), dp(4))
    }

    private fun edit(value: String, hintText: String) = EditText(this).apply {
        setText(value)
        hint = hintText
        isSingleLine = true
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun time() = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val REQ_SAVE = 1001
    }
}
