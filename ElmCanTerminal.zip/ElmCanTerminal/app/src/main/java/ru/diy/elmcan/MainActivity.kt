package ru.diy.elmcan

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), ElmClient.Listener {

    private val ui = Handler(Looper.getMainLooper())
    private val client = ElmClient(this)
    private val sniffer = SnifferStore()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    // верхняя панель
    private lateinit var hostEdit: EditText
    private lateinit var portEdit: EditText
    private lateinit var protoEdit: EditText
    private lateinit var connectBtn: TextView
    private lateinit var statusText: TextView
    private lateinit var connRow: View

    // вкладки
    private val tabButtons = ArrayList<TextView>()
    private lateinit var content: FrameLayout
    private lateinit var terminalView: View
    private lateinit var snifferView: View
    private lateinit var dashView: View
    private lateinit var wheelsTab: View
    private lateinit var wheelsView: WheelsView
    private lateinit var wheelsStartBtn: TextView
    private var wheelsRunning = false
    private val wheelRaw = arrayOfNulls<Double>(4)   // D0..D3 из 784 21 20
    private var currentTab = 0

    // терминал
    private lateinit var termOut: TextView
    private lateinit var termScroll: ScrollView
    private lateinit var termInput: EditText
    private val termScreen = StringBuilder()
    private val termLog = StringBuilder()

    // сниффер
    private lateinit var filterEdit: EditText
    private lateinit var snifStartBtn: TextView
    private lateinit var snifModeBtn: TextView
    private lateinit var snifInfo: TextView
    private lateinit var snifOut: TextView
    private var snifRunning = false
    private var snifView = 1   // 0 — таблица, 1 — расшифровка, 2 — поток
    private val snifViewNames = listOf("Вид: таблица", "Вид: расшифровка", "Вид: поток")

    // приборы
    private lateinit var dashStartBtn: TextView
    private val dashModeBtns = ArrayList<TextView>()
    private lateinit var busSection: View
    private lateinit var obdSection: View
    private var dashMode = 0   // 0 — шина, 1 — опрос ЭБУ
    private val dashValues = HashMap<String, TextView>()
    private var dashRunning = false
    private var busRunning = false

    private var pendingSave: String? = null
    private var scanRunning = false
    private lateinit var scanBtn: TextView
    private lateinit var identBtn: TextView
    private var identRunning = false
    private lateinit var lidScanBtn: TextView
    private lateinit var lidWatchBtn: TextView
    private var lidScanRunning = false
    private var lidWatchRunning = false
    private lateinit var dtcBtn: TextView
    private var dtcRunning = false

    // автопоиск
    private val auto = AutoDetect()
    private lateinit var autoTab: View
    private lateinit var autoBtn: TextView
    private lateinit var autoStatus: TextView
    private lateinit var autoOut: TextView
    private var autoRunning = false

    // ============================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Второй экземпляр окна не должен держать своё подключение: Wi-Fi ELM327 пускает
        // несколько клиентов сразу, и их команды перемешиваются. Старое подключение закрываем.
        activeClient?.let { if (it !== client) it.disconnect() }
        activeClient = client
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        root.addView(buildConnectionBar())
        root.addView(buildTabBar())
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        terminalView = buildTerminal()
        snifferView = buildSniffer()
        dashView = buildDashboard()
        wheelsTab = buildWheels()
        autoTab = buildAuto()
        content.addView(terminalView)
        content.addView(snifferView)
        content.addView(dashView)
        content.addView(wheelsTab)
        content.addView(autoTab)

        setContentView(root)
        selectTab(0)
        ui.post(refreshTask)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        client.disconnect()
        if (activeClient === client) activeClient = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ верх

    private fun buildConnectionBar(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        hostEdit = edit(prefs.getString("host", "192.168.0.10")!!, "IP адаптера")
        portEdit = edit(prefs.getString("port", "35000")!!, "порт").apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        protoEdit = edit(prefs.getString("proto", "6")!!, "прот.")
        row.addView(hostEdit, LinearLayout.LayoutParams(0, WRAP, 3f))
        row.addView(portEdit, LinearLayout.LayoutParams(0, WRAP, 1.4f))
        row.addView(protoEdit, LinearLayout.LayoutParams(0, WRAP, 0.7f))
        connRow = row
        box.addView(row)

        val status = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusText = text("Не подключено · подключите магнитолу к Wi-Fi адаптера", 14f).apply {
            setTextColor(MUTED)
            setPadding(dp(4), 0, dp(8), 0)
        }
        connectBtn = button("Подключить") { toggleConnection() }
        status.addView(statusText, LinearLayout.LayoutParams(0, WRAP, 1f))
        status.addView(connectBtn, LinearLayout.LayoutParams(WRAP, WRAP))
        box.addView(status)
        return box
    }

    private fun toggleConnection() {
        if (client.connected) {
            stopAll()
            client.disconnect()
            return
        }
        val host = hostEdit.text.toString().trim()
        val port = portEdit.text.toString().trim().toIntOrNull() ?: 35000
        val proto = protoEdit.text.toString().trim().ifEmpty { "6" }
        prefs.edit().putString("host", host).putString("port", port.toString())
            .putString("proto", proto).apply()
        client.connect(applicationContext, host, port, proto)
    }

    private fun buildTabBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Терминал", "Сниффер", "Приборы", "Колёса", "Авто").forEachIndexed { i, name ->
            val b = button(name, 16f) { selectTab(i) }
            tabButtons.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return row
    }

    private fun selectTab(i: Int) {
        if (i != currentTab) stopAll()
        currentTab = i
        terminalView.visibility = if (i == 0) View.VISIBLE else View.GONE
        snifferView.visibility = if (i == 1) View.VISIBLE else View.GONE
        dashView.visibility = if (i == 2) View.VISIBLE else View.GONE
        wheelsTab.visibility = if (i == 3) View.VISIBLE else View.GONE
        autoTab.visibility = if (i == 4) View.VISIBLE else View.GONE
        tabButtons.forEachIndexed { idx, b -> setActive(b, idx == i) }
    }

    private fun stopAll() {
        if (snifRunning) { client.stopMonitor(); snifRunning = false; snifStartBtn.text = "▶  Старт"; setActive(snifStartBtn, false) }
        if (wheelsRunning) {
            client.stopPolling(); wheelsRunning = false
            wheelsStartBtn.text = "▶  Старт"; setActive(wheelsStartBtn, false)
        }
        if (dashRunning || busRunning) {
            client.stopPolling(); dashRunning = false; busRunning = false
            dashStartBtn.text = "▶  Старт"; setActive(dashStartBtn, false)
        }
        if (scanRunning) { client.stopPolling(); scanRunning = false; scanBtn.text = "Поиск блоков"; setActive(scanBtn, false) }
        if (identRunning) { client.stopPolling(); identRunning = false; identBtn.text = "Опознать блоки"; setActive(identBtn, false) }
        if (lidScanRunning) { client.stopPolling(); lidScanRunning = false; lidScanBtn.text = "Перебор таблиц"; setActive(lidScanBtn, false) }
        if (lidWatchRunning) { client.stopPolling(); lidWatchRunning = false; lidWatchBtn.text = "Следить"; setActive(lidWatchBtn, false) }
        if (dtcRunning) { client.stopPolling(); dtcRunning = false; dtcBtn.text = "Ошибки блоков"; setActive(dtcBtn, false) }
        if (autoRunning) { client.stopPolling(); autoRunning = false; autoBtn.text = "▶  Запись"; setActive(autoBtn, false) }
    }

    // ------------------------------------------------------------ терминал

    private fun buildTerminal(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        termOut = mono(13f)
        termOut.setTextIsSelectable(true)
        termScroll = ScrollView(this).apply { addView(termOut) }
        box.addView(termScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // быстрые команды
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scanBtn = button("Поиск блоков") { toggleScan() }
        quick.addView(scanBtn)
        quick.addView(button("Поиск SRS") { startDeepScan() })
        quick.addView(button("Поиск K-line") { startKlineScan() })
        identBtn = button("Опознать блоки") { toggleIdentify() }
        quick.addView(identBtn)
        lidScanBtn = button("Перебор таблиц") { toggleLidScan() }
        quick.addView(lidScanBtn)
        lidWatchBtn = button("Следить") { toggleLidWatch() }
        quick.addView(lidWatchBtn)
        dtcBtn = button("Ошибки блоков") { toggleReadDtc() }
        quick.addView(dtcBtn)
        quick.addView(button("Стереть ошибки…") { chooseClearDtc() })
        quick.addView(button("SRS: ошибки") { runSrs(false) })
        quick.addView(button("SRS: стереть") { confirmSrsClear() })
        quick.addView(button("SRS: таблицы") { runSrsLids() })
        listOf(
            "ATI", "ATRV", "ATDP", "0100", "010C", "0105", "03", "07",
            "ATSH7E1", "2102", "ATSH7E0", "2103", "ATSH7DF", "0902", "ATZ", "ATPC",
        ).forEach { c -> quick.addView(button(c) { sendTerm(c) }) }
        box.addView(HorizontalScrollView(this).apply { addView(quick) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        termInput = edit("", "команда, напр. 2101 или ATSH7E0").apply {
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            typeface = Typeface.MONOSPACE
            setOnEditorActionListener { _, actionId, ev ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
                ) { sendFromInput(); true } else false
            }
        }
        inputRow.addView(termInput, LinearLayout.LayoutParams(0, WRAP, 1f))
        inputRow.addView(button("➤") { sendFromInput() })
        box.addView(inputRow)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(button("Очистить") {
            termScreen.setLength(0); termOut.text = ""
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        tools.addView(button("Сохранить лог") {
            saveText("terminal", "txt", termLog.toString())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(tools)
        return box
    }

    private fun toggleScan() {
        if (scanRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startScan()
        scanRunning = true
        scanBtn.text = "■  Стоп поиска"
        setActive(scanBtn, true)
    }

    private fun startDeepScan() {
        if (scanRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startDeepScan()
        scanRunning = true
        scanBtn.text = "■  Стоп поиска"
        setActive(scanBtn, true)
    }

    private fun startKlineScan() {
        if (scanRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startKlineScan()
        scanRunning = true
        scanBtn.text = "■  Стоп поиска"
        setActive(scanBtn, true)
    }

    private fun toggleLidScan() {
        if (lidScanRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        val labels = arrayOf("Двигатель 0x7E0 (коррекции форсунок и т. п.)", "АКПП 0x7E1", "Остальные блоки (ABS, 0x790, 0x7A0, 0x7A2)")
        AlertDialog.Builder(this)
            .setTitle("Перебор таблиц 21 00…21 FF — какой блок?")
            .setItems(labels) { _, which ->
                stopAll()
                client.startLidScan(when (which) { 0 -> listOf(0x7E0); 1 -> listOf(0x7E1); else -> null })
                lidScanRunning = true
                lidScanBtn.text = "■  Стоп"
                setActive(lidScanBtn, true)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun toggleLidWatch() {
        if (lidWatchRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        if (client.foundLids.isEmpty()) { toast("Сначала «Перебор таблиц»"); return }
        stopAll()
        sniffer.clear()
        snifView = 0
        snifModeBtn.text = snifViewNames[0]
        client.startLidWatch()
        lidWatchRunning = true
        lidWatchBtn.text = "■  Стоп слежения"
        setActive(lidWatchBtn, true)
        // показываем таблицу сниффера, не останавливая слежение
        currentTab = 1
        terminalView.visibility = View.GONE
        snifferView.visibility = View.VISIBLE
        dashView.visibility = View.GONE
        wheelsTab.visibility = View.GONE
        autoTab.visibility = View.GONE
        tabButtons.forEachIndexed { idx, b -> setActive(b, idx == 1) }
    }

    private fun toggleIdentify() {
        if (identRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startIdentify()
        identRunning = true
        identBtn.text = "■  Стоп"
        setActive(identBtn, true)
    }

    private fun toggleReadDtc() {
        if (dtcRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startReadDtc()
        dtcRunning = true
        dtcBtn.text = "■  Стоп"
        setActive(dtcBtn, true)
    }

    /** Выбор блока → подтверждение → стирание. Стирает только один выбранный блок. */
    private fun chooseClearDtc() {
        if (!client.connected) { toast("Сначала подключитесь"); return }
        val ecus = client.dtcTargets()
        val labels = ecus.map { String.format("0x%03X — %s", it, client.ecuName(it)) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Стереть ошибки какого блока?")
            .setItems(labels) { _, which -> confirmClearDtc(ecus[which], labels[which]) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmClearDtc(ecu: Int, label: String) {
        AlertDialog.Builder(this)
            .setTitle("Стереть ошибки $label?")
            .setMessage("Сначала прочитайте ошибки («Ошибки блоков») и сохраните лог. " +
                "Мотор заглушен, зажигание включено. Если неисправность реальная, ошибка вернётся.")
            .setPositiveButton("Стереть") { _, _ ->
                stopAll()
                client.startClearDtc(ecu)
                dtcRunning = true
                dtcBtn.text = "■  Стоп"
                setActive(dtcBtn, true)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun runSrs(clear: Boolean) {
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        if (clear) client.startSrsClear() else client.startSrsRead()
        dtcRunning = true
        dtcBtn.text = "■  Стоп"
        setActive(dtcBtn, true)
    }

    private fun runSrsLids() {
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startSrsLidScan()
        dtcRunning = true
        dtcBtn.text = "■  Стоп"
        setActive(dtcBtn, true)
    }

    private fun confirmSrsClear() {
        if (!client.connected) { toast("Сначала подключитесь"); return }
        AlertDialog.Builder(this)
            .setTitle("Стереть ошибки SRS?")
            .setMessage("Сначала прочитайте ошибки («SRS: ошибки»). Мотор заглушен, зажигание включено. " +
                "Если неисправность реальная, ошибка и лампа вернутся.")
            .setPositiveButton("Стереть") { _, _ -> runSrs(true) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun sendFromInput() {
        val c = termInput.text.toString().trim()
        if (c.isEmpty()) return
        termInput.setText("")
        sendTerm(c)
    }

    private fun sendTerm(cmd: String) {
        stopAll()
        client.send(cmd)
    }

    private fun appendTerm(s: String) {
        val stamped = time() + "  " + s.replace("\n", "\n              ") + "\n"
        termLog.append(stamped)
        termScreen.append(stamped)
        if (termScreen.length > 60_000) termScreen.delete(0, termScreen.length - 40_000)
        termOut.text = termScreen
        termScroll.post { termScroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------ сниффер

    private fun buildSniffer(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        filterEdit = edit("", "фильтр: 308 или 210/7F0").apply { typeface = Typeface.MONOSPACE }
        snifStartBtn = button("▶  Старт") { toggleSniffer() }
        row.addView(filterEdit, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(snifStartBtn)
        box.addView(row)

        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        PajeroBus.filterPresets.forEach { (label, f) ->
            presets.addView(button(label) {
                filterEdit.setText(f)
                if (snifRunning) { toggleSniffer(); toggleSniffer() }
            })
        }
        box.addView(HorizontalScrollView(this).apply { addView(presets) })

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        snifModeBtn = button(snifViewNames[snifView]) {
            snifView = (snifView + 1) % 3
            snifModeBtn.text = snifViewNames[snifView]
        }
        row2.addView(snifModeBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(button("Очистить") { sniffer.clear() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(button("CSV") {
            saveText("can_log", "csv", sniffer.exportCsv())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(button(".trc") {
            saveText("can_trace", "trc", sniffer.exportTrc())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(row2)

        snifInfo = text("", 12f).apply { setTextColor(MUTED); setPadding(dp(4), dp(4), 0, dp(4)) }
        box.addView(snifInfo)

        snifOut = mono(11.5f)
        snifOut.setHorizontallyScrolling(true)
        val hs = HorizontalScrollView(this).apply { addView(snifOut) }
        box.addView(ScrollView(this).apply { addView(hs) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    private fun toggleSniffer() {
        if (snifRunning) {
            client.stopMonitor()
            snifRunning = false
            snifStartBtn.text = "▶  Старт"
            setActive(snifStartBtn, false)
            return
        }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        val f = filterEdit.text.toString().trim()
        if (f.isNotEmpty() && !Regex("^([0-9A-Fa-f]{3}|[0-9A-Fa-f]{8})(/([0-9A-Fa-f]{3}|[0-9A-Fa-f]{8}))?$").matches(f)) {
            toast("Фильтр: ID (308) или ID/маска (210/7F0); 3 hex-символа для 11 бит, 8 — для 29 бит"); return
        }
        client.startMonitor(f)
        snifRunning = true
        snifStartBtn.text = "■  Стоп"
        setActive(snifStartBtn, true)
    }

    private var lastFrames = 0L
    private var lastRateTime = 0L
    private var rate = 0.0

    private val refreshTask = object : Runnable {
        override fun run() {
            if (currentTab == 1) {
                val now = System.currentTimeMillis()
                val total = sniffer.totalFrames
                if (now - lastRateTime >= 1000) {
                    if (lastRateTime != 0L) rate = (total - lastFrames) * 1000.0 / (now - lastRateTime)
                    lastFrames = total; lastRateTime = now
                }
                snifInfo.text = String.format(
                    Locale.US, "Кадров: %d   ID: %d   %.0f кадр/с   служебных строк: %d",
                    total, sniffer.idCount(), rate, sniffer.otherMessages
                )
                snifOut.text = when (snifView) {
                    0 -> sniffer.buildTable()
                    1 -> sniffer.buildDecoded()
                    else -> sniffer.buildRaw()
                }
            }
            if (currentTab == 2 && busRunning) {
                val vals = sniffer.decodedValues()
                for ((key, _) in PajeroBus.dashKeys) dashValues[key]?.text = vals[key] ?: "—"
            }
            ui.postDelayed(this, 300)
        }
    }

    // ------------------------------------------------------------ приборы

    private fun buildDashboard(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listOf("Шина", "ЭБУ").forEachIndexed { i, name ->
            val b = button(name, 16f) { selectDashMode(i) }
            dashModeBtns.add(b)
            top.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        dashStartBtn = button("▶  Старт", 16f) { toggleDashRun() }
        top.addView(dashStartBtn, LinearLayout.LayoutParams(0, WRAP, 1.2f))
        box.addView(top)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        busSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addTiles(this, PajeroBus.dashKeys)
            addView(hint("Данные, которые машина передаёт сама, без запросов."))
        }
        obdSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addTiles(this, Obd.pollList.flatMap { p -> p.outputs.map { it.key to "${it.title}, ${it.unit}" } })
            addView(hint("Запросы к ABS (0x784, 21 20 — колёса), двигателю (OBD-II, 21 03) и АКПП (21 02). «нет» — блок не отвечает."))
        }
        content.addView(busSection)
        content.addView(obdSection)
        box.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        selectDashMode(0)
        return box
    }

    private fun hint(s: String) = text(s, 12f).apply {
        setTextColor(MUTED)
        setPadding(dp(6), dp(8), dp(6), dp(8))
    }

    private fun addTiles(parent: LinearLayout, tiles: List<Pair<String, String>>) {
        var row: LinearLayout? = null
        tiles.forEachIndexed { i, (key, label) ->
            if (i % 2 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                parent.addView(row)
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(SURFACE, 12)
                setPadding(dp(14), dp(10), dp(14), dp(12))
            }
            card.addView(text(label, 13f).apply { setTextColor(MUTED); isSingleLine = true })
            val value = text("—", 34f).apply {
                setTextColor(TEXT)
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                isSingleLine = true
            }
            card.addView(value)
            dashValues[key] = value
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            row!!.addView(card, lp)
        }
        if (tiles.size % 2 == 1) row!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    private fun selectDashMode(m: Int) {
        if (m != dashMode && (dashRunning || busRunning)) stopAll()
        dashMode = m
        dashModeBtns.forEachIndexed { i, b -> setActive(b, i == m) }
        busSection.visibility = if (m == 0) View.VISIBLE else View.GONE
        obdSection.visibility = if (m == 1) View.VISIBLE else View.GONE
    }

    private fun toggleDashRun() {
        if (wheelsRunning) {
            client.stopPolling(); wheelsRunning = false
            wheelsStartBtn.text = "▶  Старт"; setActive(wheelsStartBtn, false)
        }
        if (dashRunning || busRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        if (dashMode == 0) {
            client.startBusScan(PajeroBus.dashScanIds); busRunning = true
        } else {
            client.startPolling(Obd.pollList); dashRunning = true
        }
        dashStartBtn.text = "■  Стоп"
        setActive(dashStartBtn, true)
    }

    // ------------------------------------------------------------ колёса

    /** Позиция (0 ПЛ, 1 ПП, 2 ЗЛ, 3 ЗП) → индекс байта D0..D3.
     *  По левому и правому поворотам: D0 ПП, D1 ПЛ, D2 ЗП, D3 ЗЛ. */
    private fun wheelMap(): IntArray {
        var m = intArrayOf(1, 0, 3, 2)
        if (prefs.getBoolean("wheels_swap_lr", false)) m = intArrayOf(m[1], m[0], m[3], m[2])
        if (prefs.getBoolean("wheels_swap_fr", false)) m = intArrayOf(m[2], m[3], m[0], m[1])
        return m
    }

    private fun updateWheels() {
        val m = wheelMap()
        wheelsView.sourceLabels = Array(4) { "D" + m[it] }
        wheelsView.speeds = Array(4) { wheelRaw[m[it]] }
    }

    // ------------------------------------------------------------ автопоиск

    private val autoMarks = listOf(
        "Мотор заглушен", "Мотор работает", "Перегазовка",
        "P", "R", "N", "D",
        "A/C вкл", "A/C выкл", "Фары вкл", "Фары выкл",
        "Тормоз нажат", "Тормоз отпущен", "Ручник вкл", "Ручник выкл",
        "Печка тепло", "Печка холод", "Датчик греют", "Датчик остыл",
    )

    private fun buildAuto(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        autoBtn = button("▶  Запись", 15f) { toggleAuto() }
        top.addView(autoBtn, LinearLayout.LayoutParams(0, WRAP, 1.2f))
        top.addView(button("Анализ", 15f) { runAutoAnalysis() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(button("CSV", 15f) { saveText("autodetect", "csv", auto.csv()) }, LinearLayout.LayoutParams(0, WRAP, 0.7f))
        top.addView(button("Очистить", 15f) {
            auto.clear(); autoOut.text = ""; autoStatus.text = "Данные очищены."
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(top)
        autoStatus = text("Нажмите «Запись». В первый раз приложение 3–5 минут ищет таблицы всех блоков.", 13f).apply {
            setTextColor(ACCENT); setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        box.addView(autoStatus)
        box.addView(hint("Метки — нажимайте в момент действия (сразу после переключения):"))
        var row: LinearLayout? = null
        val marksBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        autoMarks.forEachIndexed { i, m ->
            if (i % 4 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                marksBox.addView(row)
            }
            row?.addView(button(m, 13f) {
                if (!autoRunning) { toast("Сначала «Запись»"); return@button }
                auto.addMark(System.currentTimeMillis(), m)
                toast("Метка: $m")
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        val rest = autoMarks.size % 4
        if (rest != 0) repeat(4 - rest) { row?.addView(View(this), LinearLayout.LayoutParams(0, WRAP, 1f)) }
        box.addView(marksBox)
        autoOut = mono(12f).apply { setTextIsSelectable(true) }
        box.addView(ScrollView(this).apply { addView(autoOut) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        box.addView(hint("Как пользоваться: «Запись» → заведите мотор, сделайте 3–4 перегазовки, переключите P-R-N-D " +
            "(с тормозом), включите и выключите A/C и фары, прокатитесь — и каждый раз жмите метку. Потом «Анализ». " +
            "Приложение найдёт байты, которые совпадают с оборотами, скоростью, ОЖ, MAP, давлением в рампе, " +
            "и байты, которые меняются вместе с метками. Только чтение."))
        return box
    }

    private fun toggleAuto() {
        if (autoRunning) { stopAll(); autoStatus.text = "Запись остановлена. " + auto.summary(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startAutoRecord(auto)
        autoRunning = true
        autoBtn.text = "■  Стоп"
        setActive(autoBtn, true)
    }

    private fun runAutoAnalysis() {
        autoOut.text = "Анализ…"
        Thread {
            val r = try { auto.analyze() } catch (e: Exception) { "Ошибка анализа: ${e.message}" }
            ui.post { autoOut.text = r }
        }.start()
    }

    private fun buildWheels(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        wheelsStartBtn = button("▶  Старт", 16f) { toggleWheels() }
        top.addView(wheelsStartBtn, LinearLayout.LayoutParams(0, WRAP, 1.2f))
        top.addView(button("⇄  Лево/право", 16f) {
            prefs.edit().putBoolean("wheels_swap_lr", !prefs.getBoolean("wheels_swap_lr", false)).apply()
            updateWheels()
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(button("⇅  Перед/зад", 16f) {
            prefs.edit().putBoolean("wheels_swap_fr", !prefs.getBoolean("wheels_swap_fr", false)).apply()
            updateWheels()
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(top)
        wheelsView = WheelsView(this)
        box.addView(wheelsView, LinearLayout.LayoutParams(MATCH, 0, 1f))
        box.addView(hint("ABS 0x784, таблица 21 20. Стрелка вверх — колесо крутится быстрее среднего, вниз — медленнее. " +
            "Порядок колёс определён по поворотам; если не совпал — «Лево/право» или «Перед/зад». Единицы условные (не км/ч)."))
        updateWheels()
        return box
    }

    private fun toggleWheels() {
        if (wheelsRunning) { stopAll(); return }
        if (!client.connected) { toast("Сначала подключитесь"); return }
        stopAll()
        client.startPolling(listOf(Obd.pollList.first { it.request == "2120" }))
        wheelsRunning = true
        wheelsStartBtn.text = "■  Стоп"
        setActive(wheelsStartBtn, true)
    }

    // ------------------------------------------------------------ ElmClient.Listener

    override fun onStatus(connected: Boolean, text: String) = ui.post {
        statusText.text = text
        statusText.setTextColor(if (connected) GREEN else MUTED)
        connectBtn.text = if (connected) "Отключить" else "Подключить"
        connRow.visibility = if (connected) View.GONE else View.VISIBLE
        if (!connected) stopAll()
        appendTerm("// $text")
    }.let { }

    override fun onTraffic(tx: Boolean, text: String) = ui.post {
        appendTerm((if (tx) "> " else "< ") + text)
    }.let { }

    override fun onMonitorLine(line: String) = sniffer.onLine(line)

    override fun onTaskDone() = ui.post {
        if (scanRunning) { scanRunning = false; scanBtn.text = "Поиск блоков"; setActive(scanBtn, false) }
        if (identRunning) { identRunning = false; identBtn.text = "Опознать блоки"; setActive(identBtn, false) }
        if (lidScanRunning) { lidScanRunning = false; lidScanBtn.text = "Перебор таблиц"; setActive(lidScanBtn, false) }
        if (dtcRunning) { dtcRunning = false; dtcBtn.text = "Ошибки блоков"; setActive(dtcBtn, false) }
        if (autoRunning) { autoRunning = false; autoBtn.text = "▶  Запись"; setActive(autoBtn, false) }
    }.let { }

    override fun onAutoStatus(text: String) = ui.post { autoStatus.text = text }.let { }

    override fun onWatchData(id: String, data: IntArray) = sniffer.onPseudo(id, data)

    override fun onPidValue(key: String, value: String?) = ui.post {
        dashValues[key]?.text = value ?: "—"
        if (key.startsWith("wheel")) {
            val idx = key.removePrefix("wheel").toIntOrNull()?.minus(1)
            if (idx != null && idx in 0..3) { wheelRaw[idx] = value?.toDoubleOrNull(); updateWheels() }
        }
    }.let { }

    // ------------------------------------------------------------ сохранение (SAF)

    /**
     * Сохранение сразу в «Загрузки/ElmCan» без системного окна выбора: на многих магнитолах
     * окна ACTION_CREATE_DOCUMENT нет, и приложение падало. Android 10+ — через MediaStore,
     * старше — в папку приложения (Android/data/ru.diy.elmcan/files/Download).
     */
    private fun saveText(prefix: String, ext: String, data: String) {
        val name = prefix + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "." + ext
        val mime = when (ext) { "csv" -> "text/csv"; "txt" -> "text/plain"; else -> "application/octet-stream" }
        toast("Сохраняю…")
        Thread {
            val msg = try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ElmCan")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("система не создала файл")
                    val os = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("файл не открылся")
                    os.use { it.write(data.toByteArray(Charsets.UTF_8)) }
                    "Сохранено: Загрузки/ElmCan/$name"
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                    dir.mkdirs()
                    val f = File(dir, name)
                    f.writeText(data, Charsets.UTF_8)
                    "Сохранено: ${f.absolutePath}"
                }
            } catch (e: Throwable) {
                "Не удалось сохранить: ${e.message ?: e.javaClass.simpleName}"
            }
            ui.post {
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                appendTerm("// $msg")
            }
        }.start()
    }

    @Deprecated("Activity API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE) return
        val uri = data?.data
        val text = pendingSave
        pendingSave = null
        if (resultCode != RESULT_OK || uri == null || text == null) return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            toast("Сохранено")
        } catch (e: Exception) {
            toast("Не удалось сохранить: ${e.message}")
        }
    }

    // ------------------------------------------------------------ помощники UI

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun text(s: String, sp: Float) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    }

    private fun mono(sp: Float) = TextView(this).apply {
        typeface = Typeface.MONOSPACE
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(TEXT)
        setPadding(dp(4), dp(4), dp(4), dp(4))
    }

    private fun edit(value: String, hintText: String) = EditText(this).apply {
        setText(value)
        hint = hintText
        isSingleLine = true
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setTextColor(TEXT)
        setHintTextColor(MUTED)
        background = rounded(SURFACE, 8)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
    }

    /** Плоская кнопка: текст на скруглённой плашке, без теней. */
    private fun button(label: String, sp: Float = 14f, onClick: () -> Unit) = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        isSingleLine = true
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(TEXT)
        styleButton(this, false)
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun setActive(b: TextView, active: Boolean) = styleButton(b, active)

    /** Фон задаём до отступов: иначе View берёт отступы из фона и кнопка становится низкой. */
    private fun styleButton(b: TextView, active: Boolean) {
        b.background = InsetDrawable(rounded(if (active) ACCENT else SURFACE, 8), dp(3))
        b.setPadding(dp(16), dp(12), dp(16), dp(12))
        b.minHeight = dp(46)
        b.setTextColor(if (active) Color.BLACK else TEXT)
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun time() = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())

    companion object {
        /** Единственное живое подключение к адаптеру на всё приложение. */
        @Volatile private var activeClient: ElmClient? = null
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val REQ_SAVE = 1001
        private val BG = Color.rgb(16, 17, 19)
        private val SURFACE = Color.rgb(36, 38, 42)
        private val TEXT = Color.rgb(232, 234, 237)
        private val MUTED = Color.rgb(140, 145, 152)
        private val ACCENT = Color.rgb(102, 187, 255)
        private val GREEN = Color.rgb(129, 199, 132)
    }
}
