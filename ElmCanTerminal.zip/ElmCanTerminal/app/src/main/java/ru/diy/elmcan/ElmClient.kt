package ru.diy.elmcan

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Клиент ELM327 по Wi-Fi (TCP).
 *
 * Все обращения к адаптеру выполняются последовательно в одном рабочем потоке,
 * поэтому команды терминала, сниффер и опрос приборов не перемешиваются.
 * Колбэки Listener вызываются из рабочих потоков — UI должен сам переходить в главный поток.
 */
class ElmClient(private val listener: Listener) {

    interface Listener {
        fun onStatus(connected: Boolean, text: String)
        /** Обмен в терминале: tx=true — отправлено, false — принято. */
        fun onTraffic(tx: Boolean, text: String)
        fun onMonitorLine(line: String)
        fun onPidValue(key: String, value: String?)
        /** Данные таблицы 21 xx блока ecu (байты после 61 xx) — для слежения. */
        fun onWatchData(id: String, data: IntArray) {}
        /** Разовая задача (поиск, опознание, перебор) закончилась сама. */
        fun onTaskDone() {}
    }

    private sealed class Ev {
        class Line(val text: String) : Ev()
        object Prompt : Ev()
        object Closed : Ev()
    }

    private val events = LinkedBlockingQueue<Ev>()
    private var worker: ExecutorService = Executors.newSingleThreadExecutor()
    private var socket: Socket? = null
    private var out: OutputStream? = null

    @Volatile var connected = false
        private set
    @Volatile private var monitoring = false
    @Volatile private var polling = false

    // ---------------- Подключение ----------------

    fun connect(ctx: Context, host: String, port: Int, protocol: String) {
        if (connected) return
        if (worker.isShutdown) worker = Executors.newSingleThreadExecutor()
        worker.execute {
            try {
                listener.onStatus(false, "Подключение к $host:$port…")
                val s = createWifiSocket(ctx)
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(host, port), 5000)
                socket = s
                out = s.getOutputStream()
                connected = true
                events.clear()
                startReader(s.getInputStream())
                listener.onStatus(true, "Подключено, инициализация…")
                initAdapter(protocol)
                listener.onStatus(true, "Подключено: $host:$port")
            } catch (e: Exception) {
                closeSocket()
                listener.onStatus(false, "Ошибка: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /**
     * Адаптер — точка доступа Wi-Fi без интернета. Android в такой ситуации часто
     * отправляет трафик через мобильные данные, поэтому сокет создаём явно в Wi-Fi-сети.
     */
    private fun createWifiSocket(ctx: Context): Socket {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var wifi: Network? = null
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) { wifi = n; break }
        }
        return wifi?.socketFactory?.createSocket() ?: Socket()
    }

    private fun startReader(input: InputStream) {
        Thread({
            val buf = ByteArray(1024)
            val line = StringBuilder()
            try {
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    for (i in 0 until n) {
                        val c = (buf[i].toInt() and 0xFF).toChar()
                        when (c) {
                            '\r', '\n' -> {
                                if (line.isNotBlank()) events.put(Ev.Line(line.toString().trim()))
                                line.setLength(0)
                            }
                            '>' -> {
                                if (line.isNotBlank()) events.put(Ev.Line(line.toString().trim()))
                                line.setLength(0)
                                events.put(Ev.Prompt)
                            }
                            '\u0000' -> {} // некоторые клоны шлют нули
                            else -> line.append(c)
                        }
                    }
                }
            } catch (_: Exception) {
            }
            events.put(Ev.Closed)
            if (connected) {
                closeSocket()
                listener.onStatus(false, "Связь с адаптером потеряна")
            }
        }, "elm-reader").apply { isDaemon = true }.start()
    }

    fun disconnect() {
        monitoring = false
        polling = false
        val wasConnected = connected
        closeSocket()
        worker.shutdownNow()
        if (wasConnected) listener.onStatus(false, "Отключено")
    }

    private fun closeSocket() {
        connected = false
        monitoring = false
        polling = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        out = null
    }

    private fun write(s: String) {
        val o = out ?: throw IllegalStateException("нет соединения")
        o.write(s.toByteArray(Charsets.US_ASCII))
        o.flush()
    }

    // ---------------- Базовый обмен (только в рабочем потоке) ----------------

    /** Отправить команду и дождаться приглашения '>'. Возвращает строки ответа. */
    private fun command(cmd: String, timeoutMs: Long = 3000, echo: Boolean = true): List<String> {
        events.clear()
        if (echo) listener.onTraffic(true, cmd)
        write(cmd + "\r")
        val lines = ArrayList<String>()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = deadline - System.currentTimeMillis()
            if (left <= 0) { lines.add("(таймаут)"); break }
            val ev = events.poll(left, TimeUnit.MILLISECONDS) ?: continue
            when (ev) {
                is Ev.Line -> if (ev.text != cmd) lines.add(ev.text) // эхо, если ATE0 не сработал
                Ev.Prompt -> break
                Ev.Closed -> { lines.add("(соединение закрыто)"); break }
            }
        }
        if (echo) listener.onTraffic(false, lines.joinToString("\n").ifEmpty { "OK" })
        return lines
    }

    private fun initAdapter(protocol: String) {
        command("ATZ", 5000)
        Thread.sleep(300)
        command("ATE0")      // без эха
        command("ATL0")      // без перевода строки
        command("ATS1")      // пробелы между байтами
        command("ATH1")      // показывать заголовки (CAN ID)
        command("ATAT1")     // адаптивный таймаут
        command("ATSP$protocol")
        command("ATI")
        command("ATDP")
    }

    // ---------------- Публичные операции ----------------

    fun stopActivities() {
        monitoring = false
        polling = false
    }

    /** Команда из терминала. Останавливает сниффер/опрос. */
    fun send(cmd: String) {
        stopActivities()
        if (!connected) { listener.onTraffic(false, "(нет подключения)"); return }
        worker.execute {
            try { command(cmd.trim().uppercase(), timeoutMs = 10000) }
            catch (e: Exception) { listener.onTraffic(false, "Ошибка: ${e.message}") }
        }
    }

    /** Сброс фильтров приёма ELM327 к автоматическому режиму. */
    private fun resetFilters() {
        // ATCRA без адреса клоны v1.5 не понимают («?»); ATAR сбрасывает фильтр приёма.
        command("ATAR")
    }

    /**
     * Фильтр: "" — без фильтра; "308" — один ID (ATCRA);
     * "210/7F0" — ID и маска (ATCF/ATCM): биты маски 1 должны совпасть с ID.
     */
    private fun applyFilter(filter: String) {
        val f = filter.trim().uppercase().replace(" ", "")
        if (f.isEmpty()) { resetFilters(); return }
        val slash = f.indexOf('/')
        if (slash < 0) {
            command("ATCRA $f")
        } else {
            command("ATCF ${f.substring(0, slash)}")
            command("ATCM ${f.substring(slash + 1)}")
        }
    }

    /** Сниффер: ATMA (весь трафик) с необязательным фильтром (см. applyFilter). */
    fun startMonitor(filter: String) {
        stopActivities()
        if (!connected) return
        worker.execute {
            try {
                command("ATCAF0")                 // сырые байты, без разбора PCI
                command("ATD1")                   // показывать DLC
                applyFilter(filter)
                monitoring = true
                events.clear()
                listener.onTraffic(true, "ATMA")
                write("ATMA\r")
                var idle = false   // ELM уже стоит на '>' (пустой CR повторил бы ATMA)
                while (monitoring && connected) {
                    val ev = events.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    when (ev) {
                        is Ev.Line -> listener.onMonitorLine(ev.text)
                        Ev.Prompt -> if (monitoring) {   // BUFFER FULL и т.п. — перезапуск
                            write("ATMA\r")
                        } else idle = true
                        Ev.Closed -> monitoring = false
                    }
                }
                if (connected) {
                    if (!idle) {
                        write("\r")                   // любой символ останавливает ATMA
                        waitPrompt(1500)
                    }
                    resetFilters()
                    command("ATD0")
                    command("ATCAF1")
                }
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка сниффера: ${e.message}")
            }
        }
    }

    fun stopMonitor() { monitoring = false }

    private fun waitPrompt(timeoutMs: Long) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val ev = events.poll(100, TimeUnit.MILLISECONDS) ?: continue
            if (ev is Ev.Line) listener.onMonitorLine(ev.text)
            if (ev == Ev.Prompt || ev == Ev.Closed) return
        }
    }

    /**
     * Циклический опрос: стандартные OBD-запросы и запросы к конкретным ЭБУ (режим 21).
     * Заголовок (ATSH) меняется только когда нужен другой адрес.
     */
    fun startPolling(items: List<PollItem>) {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            val unsupported = HashSet<PollItem>()
            var header = ""
            var cycle = 0
            try {
                // принимать ответы с любых 0x7xx: ABS отвечает на 0x785, а не на 0x7E8–0x7EF
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                while (polling && connected) {
                    for (p in items) {
                        if (!polling || !connected) break
                        if (p in unsupported) continue
                        if (cycle % p.every != 0) continue
                        if (p.request == "ATRV") {
                            val l = command("ATRV", echo = false).firstOrNull { it.endsWith("V") }
                            listener.onPidValue(p.outputs[0].key, l?.removeSuffix("V"))
                            continue
                        }
                        if (header != p.header) {
                            command("ATSH" + p.header, echo = false)
                            header = p.header
                        }
                        val resp = command(p.request, timeoutMs = 2000, echo = false)
                        val data = Obd.extractData(p.request, resp)
                        if (data == null && Obd.isRejected(p.request, resp)) unsupported.add(p)
                        for (o in p.outputs) {
                            val v = data?.let { o.decode(it) }
                            listener.onPidValue(
                                o.key,
                                v?.let { Obd.format(it, o.decimals) } ?: if (p in unsupported) "нет" else null
                            )
                        }
                    }
                    cycle++
                }
                command("ATSH7DF", echo = false)
                resetFilters()
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка опроса: ${e.message}")
            }
        }
    }

    fun stopPolling() { polling = false }

    /**
     * Прослушивание шины без запросов, по одному ID за раз: ATCRA id → ATMA → первый кадр → стоп.
     * Дешёвый ELM327 не успевает за всей шиной (~500 кадров/с), а так получает только нужное.
     * Кадры уходят в onMonitorLine, как у сниффера.
     */
    fun startBusScan(ids: List<Int>) {
        stopActivities()
        if (!connected) return
        worker.execute {
            try {
                command("ATCAF0", echo = false)
                command("ATD1", echo = false)
                polling = true
                while (polling && connected) {
                    for (id in ids) {
                        if (!polling || !connected) break
                        command(String.format("ATCRA %03X", id), echo = false)
                        events.clear()
                        write("ATMA\r")
                        val deadline = System.currentTimeMillis() + 400
                        var got = false
                        var stopped = false   // ELM сам вернул '>' — пустой CR повторил бы ATMA
                        while (!got && System.currentTimeMillis() < deadline) {
                            val ev = events.poll(50, TimeUnit.MILLISECONDS) ?: continue
                            when (ev) {
                                is Ev.Line -> if (Obd.parseHexBytes(ev.text) != null) {
                                    listener.onMonitorLine(ev.text); got = true
                                }
                                Ev.Prompt -> { got = true; stopped = true }
                                Ev.Closed -> { polling = false; got = true; stopped = true }
                            }
                        }
                        if (!connected) break
                        if (!stopped) {
                            write("\r")
                            waitPrompt(800)
                        }
                    }
                }
                if (connected) {
                    resetFilters()
                    command("ATD0", echo = false)
                    command("ATCAF1", echo = false)
                }
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка прослушивания: ${e.message}")
            }
        }
    }

    /**
     * Поиск диагностических блоков: на каждый адрес 0x700–0x7F7 (кроме широковещательного 0x7DF)
     * отправляется TesterPresent (3E 00), а при молчании — чтение 21 01 (KWP, как у АКПП).
     * Оба запроса ничего в блоках не меняют. Принимаются ответы с любых адресов 0x7xx.
     */
    fun startScan() = startScanWith(listOf("3E00", "2101"), deep = false)

    /**
     * Расширенный поиск (для блоков, молчащих на 3E 00 и 21 01, например SRS):
     * дополнительно открытие сеанса 10 81, номер детали 1A 87 и чтение ошибок 18 00 FF 00.
     * Всё — только чтение. Уже известные блоки пропускаются.
     */
    fun startDeepScan() = startScanWith(listOf("3E00", "2101", "1081", "1A87", "1800FF00"), deep = true)

    private fun startScanWith(probes: List<String>, deep: Boolean) {
        stopActivities()
        if (!connected) return
        val known = if (deep) (foundEcus.ifEmpty { defaultEcus }).toSet() else emptySet()
        worker.execute {
            polling = true
            val found = LinkedHashMap<Int, String>()
            try {
                if (!deep) foundEcus.clear()
                else if (foundEcus.isEmpty()) foundEcus.addAll(defaultEcus)
                listener.onTraffic(false, if (deep)
                    "Расширенный поиск 0x700–0x7F7 (3E00, 2101, 1081, 1A87, 1800FF00), около 3–5 минут. Известные блоки пропускаются…"
                else "Поиск блоков 0x700–0x7F7, около 1–2 минут…")
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                command("ATST 19", echo = false)      // таймаут ответа ~100 мс
                for (id in 0x700..0x7F7) {
                    if (!polling || !connected) break
                    if (id == 0x7DF || id in known) continue
                    if (id % 0x20 == 0) listener.onTraffic(false, String.format("… 0x%03X", id))
                    command(String.format("ATSH %03X", id), echo = false)
                    for (probe in probes) {
                        val replies = command(probe, timeoutMs = 1500, echo = false)
                            .filter { Obd.parseHexBytes(it) != null && it.trim().split(" ")[0].length == 3 }
                        if (replies.isNotEmpty()) {
                            val text = replies.joinToString(" | ")
                            found[id] = "$probe → $text"
                            if (id !in foundEcus) foundEcus.add(id)
                            listener.onTraffic(false, String.format("✔ 0x%03X отвечает: %s → %s", id, probe, text))
                            break
                        }
                    }
                }
                listener.onTraffic(false,
                    if (found.isEmpty()) (if (deep) "Расширенный поиск окончен: новых блоков на CAN нет (возможно, SRS на K-линии)."
                        else "Поиск окончен: никто не ответил.")
                    else (if (deep) "Новые блоки добавлены в «Ошибки блоков». " else "") + "Поиск окончен. Блоки (адрес запроса → ответ):\n" +
                        found.entries.joinToString("\n") { String.format("0x%03X  %s", it.key, it.value) })
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка поиска: ${e.message}")
            } finally {
                polling = false
                try {
                    if (connected) {
                        command("ATST 32", echo = false)
                        resetFilters()
                        command("ATSH7DF", echo = false)
                    }
                } catch (_: Exception) {}
                listener.onTaskDone()
            }
        }
    }

    /** Адреса, ответившие при последнем поиске. По умолчанию — найденные на Pajero Sport 2008. */
    val foundEcus = mutableListOf<Int>()
    private val defaultEcus = listOf(0x784, 0x790, 0x7A0, 0x7A2, 0x7E0, 0x7E1)

    /**
     * Опознание блоков: для каждого адреса — номер детали (1A 87) и таблицы 21 01…21 04.
     * Только чтение. Ответы принимаются с любых 0x7xx (у части блоков ответ на адрес +1).
     */
    fun startIdentify() {
        stopActivities()
        if (!connected) return
        val ecus = if (foundEcus.isNotEmpty()) foundEcus.toList() else defaultEcus
        worker.execute {
            polling = true
            try {
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                for (id in ecus) {
                    if (!polling || !connected) break
                    listener.onTraffic(false, String.format("━━ Блок 0x%03X ━━", id))
                    command(String.format("ATSH %03X", id), echo = false)
                    for (req in listOf("1A87", "1A80", "1A90", "1A9B", "22F187", "22F18C", "22F190", "2101", "2102", "2103", "2104")) {
                        if (!polling || !connected) break
                        val resp = command(req, timeoutMs = 3000, echo = false)
                        val msgs = Obd.reassemble(resp)
                        val shown = if (msgs.isEmpty()) resp.joinToString(" ")
                        else msgs.joinToString(" | ") { m -> m.joinToString(" ") { String.format("%02X", it) } }
                        val ascii = msgs.flatMap { it.toList() }
                            .map { if (it in 0x20..0x7E) it.toChar() else '·' }.joinToString("")
                        listener.onTraffic(false, "$req → $shown" +
                            (if (msgs.isNotEmpty() && (msgs[0].getOrNull(0) == 0x5A || msgs[0].getOrNull(0) == 0x62)) "\n      текст: $ascii" else ""))
                    }
                }
                listener.onTraffic(false, "Опознание окончено. Номер детали: 4670… — ABS, 8100… — приборы, " +
                    "8637… — ETACS, 8635… — SRS, 1860… — двигатель, 8631… — АКПП.")
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка опознания: ${e.message}")
            } finally {
                polling = false
                try {
                    if (connected) { resetFilters(); command("ATSH7DF", echo = false) }
                } catch (_: Exception) {}
                listener.onTaskDone()
            }
        }
    }

    // ---------------- Ошибки (DTC) ----------------

    /** Все адреса для работы с ошибками: найденные (или известные) + двигатель и АКПП. */
    fun dtcTargets(): List<Int> {
        val base = if (foundEcus.isNotEmpty()) foundEcus.toList() else defaultEcus
        return (base + listOf(0x7E0, 0x7E1)).distinct().sorted()
    }

    private fun hex(m: IntArray) = m.joinToString(" ") { String.format("%02X", it) }

    /** Положительный ответ на сервис sid (sid + 0x40) среди собранных сообщений. */
    private fun positive(sid: Int, msgs: List<IntArray>) = msgs.firstOrNull { it.isNotEmpty() && it[0] == sid + 0x40 }

    /** Явный отказ (7F sid xx), кроме «подождите» (78). */
    private fun negative(sid: Int, msgs: List<IntArray>) =
        msgs.firstOrNull { it.size >= 3 && it[0] == 0x7F && it[1] == sid && it[2] != 0x78 }

    /**
     * Чтение ошибок одного блока: сначала KWP2000 (18 00 FF 00), при отказе — UDS (19 02 FF).
     * Только чтение. Возвращает текст для терминала.
     */
    private fun readDtcOf(ecu: Int): String {
        selectEcu(ecu)
        val tried = ArrayList<String>()

        // 1) KWP2000: 18 00 FF 00 → 58 N [hi lo статус]×N
        val kwpLines = ask(ecu, "1800FF00")
        val kwp = Obd.reassemble(kwpLines)
        positive(0x18, kwp)?.let { m ->
            val n = m.getOrNull(1) ?: 0
            if (n == 0) return "ошибок нет (KWP)"
            val codes = ArrayList<String>()
            var p = 2
            while (p + 2 < m.size) {
                codes.add("${Obd.dtcName(m[p], m[p + 1])}  ${kwpStatus(m[p + 2])}")
                p += 3
            }
            val cut = if (codes.size < n) "\n      (ответ обрезан: пришло ${codes.size} из $n)" else ""
            return "ошибок: $n (KWP)\n      " + codes.joinToString("\n      ") + cut + "\n      сырой ответ: ${hex(m)}"
        }
        tried.add("18→" + kwpLines.joinToString(" "))

        // 2) UDS: 19 02 FF → 59 02 маска [hi mid lo статус]×N
        val udsLines = ask(ecu, "1902FF")
        val uds = Obd.reassemble(udsLines)
        positive(0x19, uds)?.let { m ->
            val codes = ArrayList<String>()
            var p = 3
            while (p + 3 < m.size) {
                codes.add("${Obd.dtcName(m[p], m[p + 1])}-${String.format("%02X", m[p + 2])}  статус ${String.format("%02X", m[p + 3])}" +
                    (if (m[p + 3] and 0x01 != 0) " — активна" else " — в памяти"))
                p += 4
            }
            if (codes.isEmpty()) return "ошибок нет (UDS)"
            return "ошибок: ${codes.size} (UDS)\n      " + codes.joinToString("\n      ") + "\n      сырой ответ: ${hex(m)}"
        }
        tried.add("19→" + udsLines.joinToString(" "))

        // 3) OBD-II режим 03 (двигатель, АКПП): 43 [hi lo]×N
        val obdLines = ask(ecu, "03")
        val obd = Obd.reassemble(obdLines)
        positive(0x03, obd)?.let { m ->
            // по CAN: 43 N [hi lo]×N
            val codes = ArrayList<String>()
            var p = 2
            while (p + 1 < m.size) {
                if (m[p] != 0 || m[p + 1] != 0) codes.add(Obd.dtcName(m[p], m[p + 1]))
                p += 2
            }
            if (codes.isEmpty()) return "ошибок нет (OBD 03)"
            return "ошибок: ${codes.size} (OBD 03, подтверждённые)\n      " + codes.joinToString("\n      ") + "\n      сырой ответ: ${hex(m)}"
        }
        tried.add("03→" + obdLines.joinToString(" "))
        return "ошибки прочитать не удалось: " + tried.joinToString(" ; ")
    }

    /** Статус ошибки KWP2000 (ISO 14230-3): биты 6–5 — состояние, бит 7 — лампа. */
    private fun kwpStatus(st: Int): String {
        val state = when ((st shr 5) and 3) {
            0 -> "нет"
            1 -> "в памяти (сейчас неисправности нет)"
            2 -> "созревает"
            else -> "АКТИВНА сейчас"
        }
        val lamp = if (st and 0x80 != 0) ", горит лампа" else ""
        return String.format("[%02X] ", st) + state + lamp
    }

    /** Заголовок запроса и управление потоком для многокадровых ответов. */
    private fun selectEcu(ecu: Int) {
        command(String.format("ATSH %03X", ecu), echo = false)
        // ELM по умолчанию шлёт Flow Control на (ID ответа − 8). Блоки, отвечающие на адрес +1
        // (ABS 0x784 → 0x785), такой FC не получают и шлют только первый кадр. Задаём FC вручную.
        command(String.format("ATFCSH %03X", ecu), echo = false)
        command("ATFCSD 300000", echo = false)
        command("ATFCSM1", echo = false)
    }

    /** Запрос блоку ecu; оставляем только строки от его адресов ответа (+1 или +8) и строки без заголовка. */
    private fun ask(ecu: Int, req: String, timeoutMs: Long = 4000, echo: Boolean = false): List<String> {
        val ok = setOf(String.format("%03X", ecu + 1), String.format("%03X", ecu + 8))
        return command(req, timeoutMs = timeoutMs, echo = echo).filter { line ->
            val t = line.trim().split(Regex("\\s+"))
            Obd.parseHexBytes(line) == null || t[0].length != 3 || t[0] in ok
        }
    }

    /** Ошибки всех блоков (или одного). Только чтение. */
    fun startReadDtc(only: Int? = null) {
        stopActivities()
        if (!connected) return
        val ecus = if (only != null) listOf(only) else dtcTargets()
        worker.execute {
            polling = true
            try {
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                for (id in ecus) {
                    if (!polling || !connected) break
                    listener.onTraffic(false, String.format("━━ Ошибки 0x%03X (%s): ", id, ecuName(id)) + readDtcOf(id))
                }
                listener.onTraffic(false, "Чтение ошибок окончено. Коды B… — кузовные блоки (в т. ч. SRS), C… — шасси (ABS), " +
                    "P… — двигатель/АКПП, U… — связь.")
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка чтения DTC: ${e.message}")
            } finally {
                polling = false
                try { if (connected) { command("ATFCSM0", echo = false); resetFilters(); command("ATSH7DF", echo = false) } } catch (_: Exception) {}
                listener.onTaskDone()
            }
        }
    }

    /**
     * Стирание ошибок одного блока: KWP 14 FF 00, при отказе — UDS 14 FF FF FF.
     * Потом ошибки читаются заново, чтобы было видно, вернулись ли они.
     */
    fun startClearDtc(ecu: Int) {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            try {
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                selectEcu(ecu)
                listener.onTraffic(false, String.format("━━ Стирание ошибок 0x%03X (%s) ━━", ecu, ecuName(ecu)))
                var ok = positive(0x14, Obd.reassemble(ask(ecu, "14FF00", 5000, echo = true))) != null
                if (!ok) ok = positive(0x14, Obd.reassemble(ask(ecu, "14FFFFFF", 5000, echo = true))) != null
                if (!ok && (ecu == 0x7E0 || ecu == 0x7E1)) ok = positive(0x04, Obd.reassemble(ask(ecu, "04", 5000, echo = true))) != null
                listener.onTraffic(false, if (ok) "Блок подтвердил стирание." else "Блок не подтвердил стирание (см. ответ выше).")
                Thread.sleep(1000)
                listener.onTraffic(false, "Ошибки после стирания: " + readDtcOf(ecu))
                if (ok) listener.onTraffic(false, "Выключите и снова включите зажигание: если ошибка вернулась — неисправность реальная.")
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка стирания: ${e.message}")
            } finally {
                polling = false
                try { if (connected) { command("ATFCSM0", echo = false); resetFilters(); command("ATSH7DF", echo = false) } } catch (_: Exception) {}
                listener.onTaskDone()
            }
        }
    }

    // ---------------- SRS по K-линии (Pajero Sport KH: блок 0x58, ISO 14230 fast init) ----------------

    /** Данные из кадра K-line с заголовками: "80 F1 58 0B 58 03 …" → [58 03 …]. null — не кадр от SRS. */
    private fun kData(line: String): IntArray? {
        val clean = if (line.contains("BUS INIT")) line.substringAfterLast("OK", "") else line
        val b = Obd.parseHexBytes(clean.trim()) ?: return null
        if (b.size < 4 || b[2] != 0x58) return null
        val fmtLen = b[0] and 0x3F
        return if (fmtLen == 0) {
            val len = b[3]
            if (b.size < 4 + len) null else b.copyOfRange(4, 4 + len)
        } else {
            if (b.size < 3 + fmtLen) null else b.copyOfRange(3, 3 + fmtLen)
        }
    }

    private fun kAsk(req: String, timeoutMs: Long = 6000): List<IntArray> =
        command(req, timeoutMs = timeoutMs).mapNotNull { kData(it) }

    /** Переключение на K-линию и связь с SRS. true — блок ответил на 3E. */
    private fun srsOpen(): Boolean {
        command("ATPC")
        command("ATSP5")
        command("ATSH8158F1")
        command("ATWM8158F13E")   // поддержание связи именно с SRS, иначе блок через ~5 с отключается
        val ok = kAsk("3E", 8000).any { it.isNotEmpty() && it[0] == 0x7E }
        if (!ok) listener.onTraffic(false, "SRS не ответил на 3E (K-линия, адрес 0x58).")
        return ok
    }

    private fun srsReadText(): String {
        val m = kAsk("1800FF00").firstOrNull { it.isNotEmpty() && it[0] == 0x58 }
            ?: return "SRS: ошибки прочитать не удалось."
        val n = m.getOrNull(1) ?: 0
        if (n == 0) return "SRS: ошибок нет."
        val codes = ArrayList<String>()
        var p = 2
        while (p + 2 < m.size) {
            codes.add("${Obd.dtcName(m[p], m[p + 1])}  ${kwpStatus(m[p + 2])}")
            p += 3
        }
        return "SRS: ошибок $n\n      " + codes.joinToString("\n      ") +
            "\n      (B1476/B1477 — питание блока SRS от зажигания, B1551 — цепь лампы SRS)"
    }

    private fun srsClose() {
        try {
            if (connected) {
                command("ATPC", echo = false)
                command("ATSP6", echo = false)
                command("ATSH7DF", echo = false)
                resetFilters()
            }
        } catch (_: Exception) {}
    }

    /** Чтение ошибок SRS по K-линии. Только чтение. */
    fun startSrsRead() {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            try {
                listener.onTraffic(false, "━━ SRS (K-линия): чтение ошибок ━━")
                if (srsOpen()) listener.onTraffic(false, srsReadText())
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка SRS: ${e.message}")
            } finally {
                polling = false
                srsClose()
                listener.onTraffic(false, "Адаптер возвращён на CAN (ATSP6).")
                listener.onTaskDone()
            }
        }
    }

    /** Стирание ошибок SRS: сеанс 10 92 → 14 FF 00 → повторное чтение. */
    fun startSrsClear() {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            try {
                listener.onTraffic(false, "━━ SRS (K-линия): стирание ошибок ━━")
                if (srsOpen()) {
                    val sess = kAsk("1092").any { it.size >= 2 && it[0] == 0x50 && it[1] == 0x92 }
                    if (!sess) listener.onTraffic(false, "SRS не открыл сеанс 10 92 — стирание может не пройти.")
                    // блок может сначала ответить 7F 14 78 («жди»), затем 54 FF 00
                    val ok = kAsk("14FF00", 10000).any { it.isNotEmpty() && it[0] == 0x54 }
                    listener.onTraffic(false, if (ok) "SRS подтвердил стирание." else "SRS не подтвердил стирание (см. ответ выше).")
                    listener.onTraffic(false, "После стирания: " + srsReadText())
                    if (ok) listener.onTraffic(false, "Выключите и включите зажигание: лампа SRS должна погаснуть через ~7 с.")
                }
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка SRS: ${e.message}")
            } finally {
                polling = false
                srsClose()
                listener.onTraffic(false, "Адаптер возвращён на CAN (ATSP6).")
                listener.onTaskDone()
            }
        }
    }

    /**
     * Поиск блоков на K-линии: для каждого адреса 0x00…0xFF — быстрая инициализация (ISO 14230)
     * с заголовком 81 xx F1 и запрос «я здесь» (3E). Ответившим дополнительно — 1A 87 (номер детали).
     * Только чтение. ~2–3 с на адрес, всего 8–12 минут. После — адаптер возвращается на CAN.
     */
    fun startKlineScan() {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            val found = ArrayList<String>()
            try {
                listener.onTraffic(false, "Поиск блоков на K-линии 0x00–0xFF, 8–12 минут…")
                command("ATSP5", echo = false)
                for (addr in 0x00..0xFF) {
                    if (!polling || !connected) break
                    if (addr == 0xF1) continue                     // это адрес самого тестера
                    if (addr % 0x10 == 0) listener.onTraffic(false, String.format("… 0x%02X", addr))
                    command("ATPC", echo = false)                  // закрыть прошлую сессию → новая инициализация
                    command(String.format("ATSH81%02XF1", addr), echo = false)
                    val lines = command("3E", timeoutMs = 5000, echo = false)
                    val frames = lines.mapNotNull { line ->
                        val clean = if (line.contains("BUS INIT")) line.substringAfterLast("OK", "") else line
                        Obd.parseHexBytes(clean.trim())
                    }.filter { it.size >= 4 && it[1] == 0xF1 }
                    if (frames.isEmpty()) continue
                    val src = frames[0][2]
                    val text = frames.joinToString(" | ") { f -> f.joinToString(" ") { String.format("%02X", it) } }
                    val id = command("1A87", timeoutMs = 4000, echo = false).joinToString(" ")
                    val line = String.format("0x%02X (ответил 0x%02X): 3E → %s ; 1A87 → %s", addr, src, text, id)
                    found.add(line)
                    listener.onTraffic(false, "✔ $line")
                }
                listener.onTraffic(false,
                    if (found.isEmpty()) "Поиск K-line окончен: никто не ответил."
                    else "Поиск K-line окончен. Блоки:\n" + found.joinToString("\n") +
                        "\n(0x58 — SRS)")
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка поиска K-line: ${e.message}")
            } finally {
                polling = false
                srsClose()
                listener.onTraffic(false, "Адаптер возвращён на CAN (ATSP6).")
                listener.onTaskDone()
            }
        }
    }

    /** Перебор таблиц SRS (K-линия): опознание 1A xx и таблицы 21 00…21 FF. Только чтение. */
    fun startSrsLidScan() {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            try {
                listener.onTraffic(false, "━━ SRS (K-линия): опознание и таблицы 21 00…21 FF, 2–4 минуты ━━")
                if (srsOpen()) {
                    for (req in listOf("1A87", "1A80", "1A90", "1A9B")) {
                        val d = kAsk(req, 3000).firstOrNull { it.isNotEmpty() && it[0] == 0x5A } ?: continue
                        val ascii = d.map { if (it in 0x20..0x7E) it.toChar() else '·' }.joinToString("")
                        listener.onTraffic(false, "✔ SRS $req → ${hex(d)}   текст: $ascii")
                    }
                    var n = 0
                    for (lid in 0x00..0xFF) {
                        if (!polling || !connected) break
                        val req = String.format("21%02X", lid)
                        val d = kAsk(req, 2500).firstOrNull { it.size >= 2 && it[0] == 0x61 && it[1] == lid } ?: continue
                        n++
                        listener.onTraffic(false, String.format("✔ SRS 21 %02X → %s", lid, hex(d.copyOfRange(2, d.size))))
                    }
                    listener.onTraffic(false, "Перебор SRS окончен, таблиц: $n.")
                }
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка SRS: ${e.message}")
            } finally {
                polling = false
                srsClose()
                listener.onTraffic(false, "Адаптер возвращён на CAN (ATSP6).")
                listener.onTaskDone()
            }
        }
    }

    /** Известные блоки Pajero Sport 2008. */
    fun ecuName(id: Int): String = when (id) {
        0x7E0 -> "двигатель"
        0x7E1 -> "АКПП"
        0x784 -> "ABS"
        else -> "неизвестный"
    }

    /** Таблицы (адрес блока → номер 21 xx), ответившие при переборе. */
    val foundLids = mutableListOf<Pair<Int, Int>>()

    private fun lidTargets(): List<Int> {
        val base = if (foundEcus.isNotEmpty()) foundEcus.toList() else defaultEcus
        return base.filter { it != 0x7E0 && it != 0x7E1 }   // двигатель и АКПП уже известны
    }

    /** Перебор таблиц 21 00…21 FF у неизвестных блоков. Только чтение. */
    fun startLidScan(only: List<Int>? = null) {
        stopActivities()
        val targets = only ?: lidTargets()
        if (!connected) return
        worker.execute {
            polling = true
            try {
                foundLids.clear()
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                command("ATST 19", echo = false)
                for (ecu in targets) {
                    if (!polling || !connected) break
                    listener.onTraffic(false, String.format("━━ Блок 0x%03X: таблицы 21 00…21 FF ━━", ecu))
                    command(String.format("ATSH %03X", ecu), echo = false)
                    for (lid in 0x00..0xFF) {
                        if (!polling || !connected) break
                        val req = String.format("21%02X", lid)
                        val data = Obd.extractData(req, command(req, timeoutMs = 1500, echo = false)) ?: continue
                        foundLids.add(ecu to lid)
                        listener.onTraffic(false, String.format("✔ 0x%03X 21 %02X → %s", ecu, lid,
                            data.joinToString(" ") { String.format("%02X", it) }))
                    }
                }
                listener.onTraffic(false, "Перебор окончен, найдено таблиц: ${foundLids.size}. " +
                    "Нажмите «Следить» — изменения будут видны на вкладке «Сниффер» (вид «таблица»).")
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка перебора: ${e.message}")
            } finally {
                polling = false
                try {
                    if (connected) { command("ATST 32", echo = false); resetFilters(); command("ATSH7DF", echo = false) }
                } catch (_: Exception) {}
                listener.onTaskDone()
            }
        }
    }

    /** Циклическое чтение найденных таблиц; данные уходят в onLidData. */
    fun startLidWatch() {
        stopActivities()
        if (!connected) return
        val lids = foundLids.toList()
        if (lids.isEmpty()) { listener.onTraffic(false, "Сначала «Перебор таблиц»."); return }
        worker.execute {
            polling = true
            var header = -1
            try {
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                command("ATST 19", echo = false)
                var n = 0
                while (polling && connected) {
                    for ((ecu, lid) in lids) {
                        if (!polling || !connected) break
                        // каждые 8 таблиц — эталонная скорость от двигателя (7E0 01 0D), id «SPEED»
                        if (n++ % 8 == 0) {
                            command("ATSH 7E0", echo = false); header = 0x7E0
                            Obd.extractData("010D", command("010D", timeoutMs = 1500, echo = false))
                                ?.let { listener.onWatchData("SPEED", it) }
                        }
                        if (ecu != header) { command(String.format("ATSH %03X", ecu), echo = false); header = ecu }
                        val req = String.format("21%02X", lid)
                        val data = Obd.extractData(req, command(req, timeoutMs = 1500, echo = false)) ?: continue
                        listener.onWatchData(String.format("%03X:21%02X", ecu, lid), data)
                    }
                }
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка слежения: ${e.message}")
            } finally {
                polling = false
                try { if (connected) { command("ATST 32", echo = false); resetFilters(); command("ATSH7DF", echo = false) } } catch (_: Exception) {}
            }
        }
    }
}
