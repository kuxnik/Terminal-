package ru.diy.elmcan

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Клиент ELM327 по Wi-Fi (TCP).
 *
 * Все обращения к адаптеру выполняются последовательно в одном рабочем потоке,
 * поэтому команды терминала, сниффер и опрос приборов не перемешиваются.
 * Колбэки Listener вызываются из рабочих потоков — UI должен сам переходить в главный поток.
 */
class ElmClient(private val listener: Listener) {

    interface Listener {
        fun onStatus(connected: Boolean, text: String)
        /** Обмен в терминале: tx=true — отправлено, false — принято. */
        fun onTraffic(tx: Boolean, text: String)
        fun onMonitorLine(line: String)
        fun onPidValue(key: String, value: String?)
    }

    private sealed class Ev {
        class Line(val text: String) : Ev()
        object Prompt : Ev()
        object Closed : Ev()
    }

    private val events = LinkedBlockingQueue<Ev>()
    private var worker: ExecutorService = Executors.newSingleThreadExecutor()
    private var socket: Socket? = null
    private var out: OutputStream? = null

    @Volatile var connected = false
        private set
    @Volatile private var monitoring = false
    @Volatile private var polling = false

    // ---------------- Подключение ----------------

    fun connect(ctx: Context, host: String, port: Int, protocol: String) {
        if (connected) return
        if (worker.isShutdown) worker = Executors.newSingleThreadExecutor()
        worker.execute {
            try {
                listener.onStatus(false, "Подключение к $host:$port…")
                val s = createWifiSocket(ctx)
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(host, port), 5000)
                socket = s
                out = s.getOutputStream()
                connected = true
                events.clear()
                startReader(s.getInputStream())
                listener.onStatus(true, "Подключено, инициализация…")
                initAdapter(protocol)
                listener.onStatus(true, "Подключено: $host:$port")
            } catch (e: Exception) {
                closeSocket()
                listener.onStatus(false, "Ошибка: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /**
     * Адаптер — точка доступа Wi-Fi без интернета. Android в такой ситуации часто
     * отправляет трафик через мобильные данные, поэтому сокет создаём явно в Wi-Fi-сети.
     */
    private fun createWifiSocket(ctx: Context): Socket {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var wifi: Network? = null
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) { wifi = n; break }
        }
        return wifi?.socketFactory?.createSocket() ?: Socket()
    }

    private fun startReader(input: InputStream) {
        Thread({
            val buf = ByteArray(1024)
            val line = StringBuilder()
            try {
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    for (i in 0 until n) {
                        val c = (buf[i].toInt() and 0xFF).toChar()
                        when (c) {
                            '\r', '\n' -> {
                                if (line.isNotBlank()) events.put(Ev.Line(line.toString().trim()))
                                line.setLength(0)
                            }
                            '>' -> {
                                if (line.isNotBlank()) events.put(Ev.Line(line.toString().trim()))
                                line.setLength(0)
                                events.put(Ev.Prompt)
                            }
                            '\u0000' -> {} // некоторые клоны шлют нули
                            else -> line.append(c)
                        }
                    }
                }
            } catch (_: Exception) {
            }
            events.put(Ev.Closed)
            if (connected) {
                closeSocket()
                listener.onStatus(false, "Связь с адаптером потеряна")
            }
        }, "elm-reader").apply { isDaemon = true }.start()
    }

    fun disconnect() {
        monitoring = false
        polling = false
        val wasConnected = connected
        closeSocket()
        worker.shutdownNow()
        if (wasConnected) listener.onStatus(false, "Отключено")
    }

    private fun closeSocket() {
        connected = false
        monitoring = false
        polling = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        out = null
    }

    private fun write(s: String) {
        val o = out ?: throw IllegalStateException("нет соединения")
        o.write(s.toByteArray(Charsets.US_ASCII))
        o.flush()
    }

    // ---------------- Базовый обмен (только в рабочем потоке) ----------------

    /** Отправить команду и дождаться приглашения '>'. Возвращает строки ответа. */
    private fun command(cmd: String, timeoutMs: Long = 3000, echo: Boolean = true): List<String> {
        events.clear()
        if (echo) listener.onTraffic(true, cmd)
        write(cmd + "\r")
        val lines = ArrayList<String>()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = deadline - System.currentTimeMillis()
            if (left <= 0) { lines.add("(таймаут)"); break }
            val ev = events.poll(left, TimeUnit.MILLISECONDS) ?: continue
            when (ev) {
                is Ev.Line -> if (ev.text != cmd) lines.add(ev.text) // эхо, если ATE0 не сработал
                Ev.Prompt -> break
                Ev.Closed -> { lines.add("(соединение закрыто)"); break }
            }
        }
        if (echo) listener.onTraffic(false, lines.joinToString("\n").ifEmpty { "OK" })
        return lines
    }

    private fun initAdapter(protocol: String) {
        command("ATZ", 5000)
        Thread.sleep(300)
        command("ATE0")      // без эха
        command("ATL0")      // без перевода строки
        command("ATS1")      // пробелы между байтами
        command("ATH1")      // показывать заголовки (CAN ID)
        command("ATAT1")     // адаптивный таймаут
        command("ATSP$protocol")
        command("ATI")
        command("ATDP")
    }

    // ---------------- Публичные операции ----------------

    fun stopActivities() {
        monitoring = false
        polling = false
    }

    /** Команда из терминала. Останавливает сниффер/опрос. */
    fun send(cmd: String) {
        stopActivities()
        if (!connected) { listener.onTraffic(false, "(нет подключения)"); return }
        worker.execute {
            try { command(cmd.trim().uppercase(), timeoutMs = 10000) }
            catch (e: Exception) { listener.onTraffic(false, "Ошибка: ${e.message}") }
        }
    }

    /** Сброс фильтров приёма ELM327 к автоматическому режиму. */
    private fun resetFilters() {
        // ATCRA без адреса клоны v1.5 не понимают («?»); ATAR сбрасывает фильтр приёма.
        command("ATAR")
    }

    /**
     * Фильтр: "" — без фильтра; "308" — один ID (ATCRA);
     * "210/7F0" — ID и маска (ATCF/ATCM): биты маски 1 должны совпасть с ID.
     */
    private fun applyFilter(filter: String) {
        val f = filter.trim().uppercase().replace(" ", "")
        if (f.isEmpty()) { resetFilters(); return }
        val slash = f.indexOf('/')
        if (slash < 0) {
            command("ATCRA $f")
        } else {
            command("ATCF ${f.substring(0, slash)}")
            command("ATCM ${f.substring(slash + 1)}")
        }
    }

    /** Сниффер: ATMA (весь трафик) с необязательным фильтром (см. applyFilter). */
    fun startMonitor(filter: String) {
        stopActivities()
        if (!connected) return
        worker.execute {
            try {
                command("ATCAF0")                 // сырые байты, без разбора PCI
                command("ATD1")                   // показывать DLC
                applyFilter(filter)
                monitoring = true
                events.clear()
                listener.onTraffic(true, "ATMA")
                write("ATMA\r")
                var idle = false   // ELM уже стоит на '>' (пустой CR повторил бы ATMA)
                while (monitoring && connected) {
                    val ev = events.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    when (ev) {
                        is Ev.Line -> listener.onMonitorLine(ev.text)
                        Ev.Prompt -> if (monitoring) {   // BUFFER FULL и т.п. — перезапуск
                            write("ATMA\r")
                        } else idle = true
                        Ev.Closed -> monitoring = false
                    }
                }
                if (connected) {
                    if (!idle) {
                        write("\r")                   // любой символ останавливает ATMA
                        waitPrompt(1500)
                    }
                    resetFilters()
                    command("ATD0")
                    command("ATCAF1")
                }
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка сниффера: ${e.message}")
            }
        }
    }

    fun stopMonitor() { monitoring = false }

    private fun waitPrompt(timeoutMs: Long) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val ev = events.poll(100, TimeUnit.MILLISECONDS) ?: continue
            if (ev is Ev.Line) listener.onMonitorLine(ev.text)
            if (ev == Ev.Prompt || ev == Ev.Closed) return
        }
    }

    /**
     * Циклический опрос: стандартные OBD-запросы и запросы к конкретным ЭБУ (режим 21).
     * Заголовок (ATSH) меняется только когда нужен другой адрес.
     */
    fun startPolling(items: List<PollItem>) {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            val unsupported = HashSet<PollItem>()
            var header = ""
            var cycle = 0
            try {
                while (polling && connected) {
                    for (p in items) {
                        if (!polling || !connected) break
                        if (p in unsupported) continue
                        if (cycle % p.every != 0) continue
                        if (p.request == "ATRV") {
                            val l = command("ATRV", echo = false).firstOrNull { it.endsWith("V") }
                            listener.onPidValue(p.outputs[0].key, l?.removeSuffix("V"))
                            continue
                        }
                        if (header != p.header) {
                            command("ATSH" + p.header, echo = false)
                            header = p.header
                        }
                        val resp = command(p.request, timeoutMs = 2000, echo = false)
                        val data = Obd.extractData(p.request, resp)
                        if (data == null && Obd.isRejected(p.request, resp)) unsupported.add(p)
                        for (o in p.outputs) {
                            val v = data?.let { o.decode(it) }
                            listener.onPidValue(
                                o.key,
                                v?.let { Obd.format(it, o.decimals) } ?: if (p in unsupported) "нет" else null
                            )
                        }
                    }
                    cycle++
                }
                command("ATSH7DF", echo = false)
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка опроса: ${e.message}")
            }
        }
    }

    fun stopPolling() { polling = false }

    /**
     * Прослушивание шины без запросов, по одному ID за раз: ATCRA id → ATMA → первый кадр → стоп.
     * Дешёвый ELM327 не успевает за всей шиной (~500 кадров/с), а так получает только нужное.
     * Кадры уходят в onMonitorLine, как у сниффера.
     */
    fun startBusScan(ids: List<Int>) {
        stopActivities()
        if (!connected) return
        worker.execute {
            try {
                command("ATCAF0", echo = false)
                command("ATD1", echo = false)
                polling = true
                while (polling && connected) {
                    for (id in ids) {
                        if (!polling || !connected) break
                        command(String.format("ATCRA %03X", id), echo = false)
                        events.clear()
                        write("ATMA\r")
                        val deadline = System.currentTimeMillis() + 400
                        var got = false
                        var stopped = false   // ELM сам вернул '>' — пустой CR повторил бы ATMA
                        while (!got && System.currentTimeMillis() < deadline) {
                            val ev = events.poll(50, TimeUnit.MILLISECONDS) ?: continue
                            when (ev) {
                                is Ev.Line -> if (Obd.parseHexBytes(ev.text) != null) {
                                    listener.onMonitorLine(ev.text); got = true
                                }
                                Ev.Prompt -> { got = true; stopped = true }
                                Ev.Closed -> { polling = false; got = true; stopped = true }
                            }
                        }
                        if (!connected) break
                        if (!stopped) {
                            write("\r")
                            waitPrompt(800)
                        }
                    }
                }
                if (connected) {
                    resetFilters()
                    command("ATD0", echo = false)
                    command("ATCAF1", echo = false)
                }
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка прослушивания: ${e.message}")
            }
        }
    }

    /**
     * Поиск диагностических блоков: на каждый адрес 0x700–0x7F7 (кроме широковещательного 0x7DF)
     * отправляется TesterPresent (3E 00), а при молчании — чтение 21 01 (KWP, как у АКПП).
     * Оба запроса ничего в блоках не меняют. Принимаются ответы с любых адресов 0x7xx.
     */
    fun startScan() {
        stopActivities()
        if (!connected) return
        worker.execute {
            polling = true
            val found = LinkedHashMap<Int, String>()
            try {
                listener.onTraffic(false, "Поиск блоков 0x700–0x7F7, около 1–2 минут…")
                command("ATCF 700", echo = false)
                command("ATCM 700", echo = false)
                command("ATST 19", echo = false)      // таймаут ответа ~100 мс
                for (id in 0x700..0x7F7) {
                    if (!polling || !connected) break
                    if (id == 0x7DF) continue
                    if (id % 0x20 == 0) listener.onTraffic(false, String.format("… 0x%03X", id))
                    command(String.format("ATSH %03X", id), echo = false)
                    for (probe in listOf("3E00", "2101")) {
                        val replies = command(probe, timeoutMs = 1500, echo = false)
                            .filter { Obd.parseHexBytes(it) != null && it.trim().split(" ")[0].length == 3 }
                        if (replies.isNotEmpty()) {
                            val text = replies.joinToString(" | ")
                            found[id] = "$probe → $text"
                            listener.onTraffic(false, String.format("✔ 0x%03X отвечает: %s → %s", id, probe, text))
                            break
                        }
                    }
                }
                listener.onTraffic(false,
                    if (found.isEmpty()) "Поиск окончен: никто не ответил."
                    else "Поиск окончен. Блоки (адрес запроса → ответ):\n" +
                        found.entries.joinToString("\n") { String.format("0x%03X  %s", it.key, it.value) })
            } catch (e: Exception) {
                listener.onTraffic(false, "Ошибка поиска: ${e.message}")
            } finally {
                polling = false
                try {
                    if (connected) {
                        command("ATST 32", echo = false)
                        resetFilters()
                        command("ATSH7DF", echo = false)
                    }
                } catch (_: Exception) {}
            }
        }
    }
}
