package ru.diy.elmcan

import android.graphics.Color
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Накопление кадров сниффера: таблица уникальных ID, сырой поток и лог для сохранения. */
class SnifferStore {

    class FrameStat(val id: String) {
        var data: IntArray = IntArray(0)
        var count = 0L
        var lastTime = 0L
        var periodMs = 0L
        var changedAt = LongArray(8)
    }

    private val lock = Any()
    private val stats = HashMap<String, FrameStat>()
    private val raw = ArrayDeque<String>()
    private val log = ArrayList<String>()
    private var startTime = 0L
    var totalFrames = 0L
        private set
    var otherMessages = 0L
        private set
    private var logTruncated = false

    fun clear() = synchronized(lock) {
        stats.clear(); raw.clear(); log.clear()
        totalFrames = 0; otherMessages = 0; startTime = 0; logTruncated = false
    }

    fun onLine(line: String) {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            if (startTime == 0L) startTime = now
            val t = now - startTime
            raw.addLast(String.format(Locale.US, "%8.3f  %s", t / 1000.0, line))
            while (raw.size > 400) raw.removeFirst()

            val parsed = parseFrame(line)
            if (parsed == null) {
                otherMessages++
                addLog("$t;MSG;$line")
                return
            }
            val (id, data) = parsed
            totalFrames++
            addLog("$t;$id;${data.joinToString(" ") { String.format("%02X", it) }}")
            val st = stats.getOrPut(id) { FrameStat(id) }
            if (st.changedAt.size < data.size) st.changedAt = st.changedAt.copyOf(data.size)
            for (i in data.indices) {
                if (i >= st.data.size || st.data[i] != data[i]) {
                    if (st.count > 0) st.changedAt[i] = now
                }
            }
            if (st.lastTime != 0L) {
                val p = now - st.lastTime
                st.periodMs = if (st.periodMs == 0L) p else (st.periodMs * 7 + p) / 8
            }
            st.data = data
            st.lastTime = now
            st.count++
        }
    }

    private fun addLog(s: String) {
        if (log.size < 300_000) log.add(s) else logTruncated = true
    }

    /**
     * Строки ATMA при ATH1 ATS1 ATD1:
     *   "7E8 8 04 41 0C 1A F8 00 00 00"            (11 бит)
     *   "18 DA F1 10 8 04 41 0C 1A F8 00 00 00"    (29 бит)
     * DLC может отсутствовать, если клон игнорирует ATD1.
     */
    private fun parseFrame(line: String): Pair<String, IntArray>? {
        val t = line.trim().split(Regex("\\s+"))
        if (t.isEmpty() || t.any { tok -> tok.any { !it.isLetterOrDigit() } }) return null
        if (t.any { it.toIntOrNull(16) == null }) return null
        val dlcIdx = t.indexOfFirst { it.length == 1 }
        val idTokens: List<String>
        val dataTokens: List<String>
        when {
            dlcIdx > 0 -> { idTokens = t.subList(0, dlcIdx); dataTokens = t.subList(dlcIdx + 1, t.size) }
            t[0].length == 3 -> { idTokens = t.subList(0, 1); dataTokens = t.subList(1, t.size) }
            t.size >= 4 && t.take(4).all { it.length == 2 } -> { idTokens = t.subList(0, 4); dataTokens = t.subList(4, t.size) }
            else -> return null
        }
        val id = idTokens.joinToString("").uppercase()
        val data = IntArray(dataTokens.size) { dataTokens[it].toInt(16) }
        return id to data
    }

    fun buildTable(): CharSequence {
        val now = System.currentTimeMillis()
        val sb = SpannableStringBuilder()
        synchronized(lock) {
            sb.append("ID        ДАННЫЕ                     КОЛ-ВО  ПЕРИОД\n")
            val rows = stats.values.sortedBy { it.id.toLong(16) }
            for (st in rows) {
                sb.append(st.id.padEnd(10))
                for (i in st.data.indices) {
                    val start = sb.length
                    sb.append(String.format("%02X", st.data[i]))
                    val changed = i < st.changedAt.size && now - st.changedAt[i] < 1500
                    if (changed) {
                        sb.setSpan(ForegroundColorSpan(Color.rgb(255, 152, 0)), start, sb.length,
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    sb.append(' ')
                }
                for (i in st.data.size until 8) sb.append("   ")
                sb.append(String.format(Locale.US, "%7d %5d мс", st.count, st.periodMs))
                st.id.toIntOrNull(16)?.let { PajeroBus.known[it] }?.let { sb.append("  ").append(it.name) }
                sb.append('\n')
            }
        }
        return sb
    }

    /** Вид «Расшифровка»: известные кадры Pajero по группам, затем неизвестные ID. */
    fun buildDecoded(): CharSequence {
        val now = System.currentTimeMillis()
        val sb = SpannableStringBuilder()
        val dim = Color.rgb(140, 140, 140)
        val head = Color.rgb(129, 199, 132)
        fun colored(s: String, c: Int) {
            val start = sb.length
            sb.append(s)
            sb.setSpan(ForegroundColorSpan(c), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        synchronized(lock) {
            val byId = stats.values.mapNotNull { st -> st.id.toIntOrNull(16)?.let { it to st } }.toMap()
            for (group in PajeroBus.GROUPS) {
                val infos = PajeroBus.known.values.filter { it.group == group }.sortedBy { it.id }
                if (infos.none { byId.containsKey(it.id) }) continue
                colored("■ $group\n", head)
                for (info in infos) {
                    val st = byId[info.id] ?: continue
                    val age = now - st.lastTime
                    sb.append(String.format(Locale.US, "  %03X  %s", info.id, info.name))
                    colored(String.format(Locale.US, "  (%s, ×%d%s)\n", info.period, st.count,
                        if (age > 3000) ", ${age / 1000} с назад" else ""), dim)
                    val fields = PajeroBus.decode(info.id, st.data)
                    if (fields.isEmpty()) {
                        colored("       " + st.data.joinToString(" ") { String.format("%02X", it) } + "\n", dim)
                    }
                    for (f in fields) {
                        sb.append("       ").append(f.title).append(": ")
                        colored(f.value + (if (f.unit.isNotEmpty()) " " + f.unit else ""), Color.WHITE)
                        sb.append('\n')
                    }
                }
            }
            val unknown = byId.keys.filter { !PajeroBus.known.containsKey(it) }.sorted()
            if (unknown.isNotEmpty()) {
                colored("■ Неизвестные ID\n", head)
                for (id in unknown) {
                    val st = byId[id]!!
                    sb.append(String.format(Locale.US, "  %03X  ", id))
                    sb.append(st.data.joinToString(" ") { String.format("%02X", it) })
                    colored(String.format(Locale.US, "  ×%d, %d мс\n", st.count, st.periodMs), dim)
                }
            }
            if (byId.isEmpty()) sb.append("Кадров пока нет. Запустите сниффер.")
        }
        return sb
    }

    /** Последние расшифрованные значения всех известных кадров: ключ → "значение". */
    fun decodedValues(maxAgeMs: Long = 5000): Map<String, String> {
        val now = System.currentTimeMillis()
        val res = HashMap<String, String>()
        synchronized(lock) {
            for (st in stats.values) {
                if (now - st.lastTime > maxAgeMs) continue
                val id = st.id.toIntOrNull(16) ?: continue
                for (f in PajeroBus.decode(id, st.data)) res[f.key] = f.value
            }
        }
        for (f in PajeroBus.derived(res)) res[f.key] = f.value
        return res
    }

    fun buildRaw(): String = synchronized(lock) { raw.joinToString("\n") }

    fun idCount(): Int = synchronized(lock) { stats.size }

    /**
     * Trace-файл CarBusAnalyzer (CAN Hacker), формат версии 2 — открывается в CarBusAnalyzer
     * (Отладчик, DBC, агрегатор) и в SavvyCAN. Строки разделяются символом '\r', поля — табуляцией:
     *   SS,mmm  канал  флаги(0004)  ID  DLC  данные(23 симв.)  00000000  ASCII(8 симв.)
     * Секунды в метке времени идут по кругу 0..59, как в оригинальных логах.
     */
    fun exportTrc(): String = synchronized(lock) {
        val rows = StringBuilder()
        var count = 0
        var lastT = 0L
        for (entry in log) {
            val p = entry.split(';', limit = 3)
            if (p.size < 3 || p[1] == "MSG") continue
            val t = p[0].toLongOrNull() ?: continue
            val bytes = if (p[2].isBlank()) emptyList() else p[2].trim().split(' ')
            val ascii = StringBuilder()
            for (b in bytes) {
                val v = b.toIntOrNull(16) ?: 0
                ascii.append(if (v in 32..125) v.toChar() else ' ')
            }
            rows.append(String.format(Locale.US, "%02d,%03d", (t / 1000) % 60, t % 1000)).append('\t')
                .append("1\t0004\t")
                .append(p[1]).append('\t')
                .append(bytes.size).append('\t')
                .append(bytes.joinToString(" ").padEnd(23)).append('\t')
                .append("00000000\t")
                .append(ascii.toString().padEnd(8)).append("\t\r")
            count++
            lastT = t
        }
        val dur = String.format(
            Locale.US, "%02d:%02d:%02d.%03d",
            lastT / 3_600_000, (lastT / 60_000) % 60, (lastT / 1000) % 60, lastT % 1000
        )
        "@ TEXT @ 2 @ 64 @ 0 @ $count @ $lastT @ $dur @\r" + rows
    }

    fun exportCsv(): String = synchronized(lock) {
        val head = "# ELM CAN Терминал, лог сниффера, " +
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + "\n" +
            (if (logTruncated) "# лог обрезан (лимит 300000 строк)\n" else "") +
            "time_ms;id;data\n"
        head + log.joinToString("\n") + "\n"
    }
}
