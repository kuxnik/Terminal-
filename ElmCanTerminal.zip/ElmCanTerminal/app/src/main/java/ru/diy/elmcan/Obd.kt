package ru.diy.elmcan

import java.util.Locale

/** Один выводимый параметр (плитка) из ответа на запрос. */
class Output(
    val key: String,
    val title: String,
    val unit: String,
    val decimals: Int = 0,
    /** Получает байты данных после эха сервиса и PID (A = d[0], B = d[1], …). */
    val decode: (IntArray) -> Double?,
)

/**
 * Запрос, который приложение циклически отправляет ЭБУ.
 * header — CAN-адрес запроса (ATSH): 7DF — все ЭБУ (OBD), 7E0 — двигатель, 7E1 — АКПП.
 * every — опрашивать раз в N циклов (для медленно меняющихся величин).
 */
class PollItem(
    val header: String,
    val request: String,
    val outputs: List<Output>,
    val every: Int = 1,
)

object Obd {

    /** "7E8 04 41 0C" → [0x7E8, 0x04, 0x41, 0x0C]; null, если в строке не только hex. */
    fun parseHexBytes(line: String): IntArray? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.isEmpty() || parts[0].isEmpty()) return null
        val res = IntArray(parts.size)
        for ((i, p) in parts.withIndex()) {
            if (p.length > 3) return null
            res[i] = p.toIntOrNull(16) ?: return null
        }
        return res
    }

    /**
     * Сборка ответов ISO-TP из строк ELM327 при ATH1 ATS1 ATCAF1:
     *   "7E8 04 41 0C 1A F8"                      — одиночный кадр
     *   "7E9 10 0C 61 02 00 06 B0 00"            — первый кадр
     *   "7E9 21 00 6C 70 00 60 01 00"            — продолжение
     * Без заголовков (ATH0) строки возвращаются как есть.
     */
    fun reassemble(lines: List<String>): List<IntArray> {
        val result = ArrayList<IntArray>()
        val pending = HashMap<String, Pair<Int, ArrayList<Int>>>() // заголовок → (длина, данные)
        for (line in lines) {
            val tokens = line.trim().split(Regex("\\s+"))
            if (tokens.size < 2) continue
            val bytes = parseHexBytes(line) ?: continue
            if (tokens[0].length != 3) { result.add(bytes); continue } // нет заголовка
            val hdr = tokens[0]
            val pci = bytes[1]
            when (pci shr 4) {
                0 -> {
                    val len = pci and 0x0F
                    if (bytes.size >= 2 + len) result.add(bytes.copyOfRange(2, 2 + len))
                }
                1 -> {
                    if (bytes.size < 3) continue
                    val total = ((pci and 0x0F) shl 8) or bytes[2]
                    val buf = ArrayList<Int>()
                    for (i in 3 until bytes.size) buf.add(bytes[i])
                    pending[hdr] = total to buf
                }
                2 -> {
                    val p = pending[hdr] ?: continue
                    for (i in 2 until bytes.size) p.second.add(bytes[i])
                    if (p.second.size >= p.first) {
                        result.add(p.second.subList(0, p.first).toIntArray())
                        pending.remove(hdr)
                    }
                }
            }
        }
        // недособранные ответы тоже отдаём — вдруг нужные байты уже пришли
        for (p in pending.values) result.add(p.second.toIntArray())
        return result
    }

    /** Данные после положительного ответа: для "010C" ищем "41 0C …", для "2102" — "61 02 …". */
    fun extractData(request: String, lines: List<String>): IntArray? {
        if (request.length < 4) return null
        val sid = request.substring(0, 2).toIntOrNull(16) ?: return null
        val pid = request.substring(2, 4).toIntOrNull(16) ?: return null
        for (msg in reassemble(lines)) {
            for (i in 0 until msg.size - 1) {
                if (msg[i] == sid + 0x40 && msg[i + 1] == pid) return msg.copyOfRange(i + 2, msg.size)
            }
        }
        return null
    }

    /** true, если ЭБУ явно отказал (NO DATA, ?, отрицательный ответ 7F). */
    fun isRejected(request: String, lines: List<String>): Boolean {
        if (lines.any { it.contains("NO DATA") || it.trim() == "?" || it.contains("ERROR") }) return true
        val sid = request.substring(0, 2).toIntOrNull(16) ?: return false
        return reassemble(lines).any { m -> m.size >= 2 && m[0] == 0x7F && m[1] == sid }
    }

    fun format(v: Double, decimals: Int): String = String.format(Locale.US, "%.${decimals}f", v)

    private fun a(d: IntArray) = d.getOrNull(0)
    private fun ab(d: IntArray): Int? = if (d.size >= 2) d[0] * 256 + d[1] else null

    /** Стандартные OBD-II (режим 01, широковещательно 7DF) + Pajero Sport II (режим 21). */
    val pollList: List<PollItem> = listOf(
        // ABS Pajero Sport 2008: запрос 0x784, ответ 0x785, таблица 21 20 — скорости колёс,
        // предположительно 1 км/ч на отсчёт; порядок колёс не подтверждён.
        PollItem(
            "784", "2120", listOf(
                Output("wheel1", "Колесо 1 (D0)", "км/ч") { d -> d.getOrNull(0)?.toDouble() },
                Output("wheel2", "Колесо 2 (D1)", "км/ч") { d -> d.getOrNull(1)?.toDouble() },
                Output("wheel3", "Колесо 3 (D2)", "км/ч") { d -> d.getOrNull(2)?.toDouble() },
                Output("wheel4", "Колесо 4 (D3)", "км/ч") { d -> d.getOrNull(3)?.toDouble() },
            )
        ),
        PollItem("7DF", "010C", listOf(Output("010C", "Обороты", "об/мин") { d -> ab(d)?.let { it / 4.0 } })),
        PollItem("7DF", "010D", listOf(Output("010D", "Скорость", "км/ч") { d -> a(d)?.toDouble() })),
        PollItem("7DF", "0105", listOf(Output("0105", "ОЖ", "°C") { d -> a(d)?.let { it - 40.0 } })),
        PollItem("7DF", "010F", listOf(Output("010F", "Впуск", "°C") { d -> a(d)?.let { it - 40.0 } })),
        PollItem("7DF", "010B", listOf(Output("010B", "Давл. впуска (MAP)", "кПа") { d -> a(d)?.toDouble() })),
        PollItem("7DF", "0133", listOf(Output("0133", "Барометр", "кПа") { d -> a(d)?.toDouble() }), every = 10),
        PollItem("7DF", "0111", listOf(Output("0111", "Дроссельная заслонка (дизель: открыта на ХХ)", "%") { d -> a(d)?.let { it * 100.0 / 255 } })),
        PollItem("7DF", "0110", listOf(Output("0110", "Расход воздуха", "г/с", 1) { d -> ab(d)?.let { it / 100.0 } })),
        PollItem("7DF", "0123", listOf(Output("0123", "Давл. в рампе", "МПа", 1) { d -> ab(d)?.let { it * 10.0 / 1000 } })),
        PollItem("7DF", "ATRV", listOf(Output("ATRV", "Напряжение", "В", 1) { null }), every = 3),
        // Pajero Sport II (KH): KWP 0x21, разбор как в igkov/bcomp11.
        // Ответ АКПП: 61 02 A B C D E F G H I … (проверено на KH 2008: F−40 = ATF, G = питание)
        PollItem(
            "7E1", "2102", listOf(
                Output("at_temp", "Масло АКПП (ATF)", "°C") { d -> d.getOrNull(5)?.let { it - 40.0 } },
                Output("at_in", "АКПП вход", "об/мин") { d ->
                    if (d.size >= 3) d[1] * 128.0 + d[2] / 2.0 else null
                },
                Output("at_out", "АКПП выход", "об/мин") { d ->
                    if (d.size >= 5) d[3] * 128.0 + d[4] / 2.0 else null
                },
                Output("at_volt", "АКПП питание соленоидов", "В", 1) { d ->
                    d.getOrNull(6)?.let { it * 33.15 / 255 }
                },
            )
        ),
        // Пробег из ЭБУ двигателя: 61 03 A B C D → B·65536 + C·256 + D км
        PollItem(
            "7E0", "2103", listOf(
                Output("odo", "Пробег по ЭБУ двигателя (≠ одометр)", "км") { d ->
                    if (d.size >= 4) (d[1] * 65536 + d[2] * 256 + d[3]).toDouble() else null
                },
            ), every = 20
        ),
    )
}
