package ru.diy.elmcan

import java.util.Locale

/** Один выводимый параметр (плитка) из ответа на запрос. */
class Output(
    val key: String,
    val title: String,
    val unit: String,
    val decimals: Int = 0,
    /** Получает байты данных после эха сервиса и PID (A = d[0], B = d[1], …). */
    val decode: (IntArray) -> Double?,
)

/**
 * Запрос, который приложение циклически отправляет ЭБУ.
 * header — CAN-адрес запроса (ATSH): 7DF — все ЭБУ (OBD), 7E0 — двигатель, 7E1 — АКПП.
 * every — опрашивать раз в N циклов (для медленно меняющихся величин).
 */
class PollItem(
    val header: String,
    val request: String,
    val outputs: List<Output>,
    val every: Int = 1,
)

object Obd {

    /** "7E8 04 41 0C" → [0x7E8, 0x04, 0x41, 0x0C]; null, если в строке не только hex. */
    fun parseHexBytes(line: String): IntArray? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.isEmpty() || parts[0].isEmpty()) return null
        val res = IntArray(parts.size)
        for ((i, p) in parts.withIndex()) {
            if (p.length > 3) return null
            res[i] = p.toIntOrNull(16) ?: return null
        }
        return res
    }

    /**
     * Сборка ответов ISO-TP из строк ELM327 при ATH1 ATS1 ATCAF1:
     *   "7E8 04 41 0C 1A F8"                      — одиночный кадр
     *   "7E9 10 0C 61 02 00 06 B0 00"            — первый кадр
     *   "7E9 21 00 6C 70 00 60 01 00"            — продолжение
     * Без заголовков (ATH0) строки возвращаются как есть.
     */
    fun reassemble(lines: List<String>): List<IntArray> {
        val result = ArrayList<IntArray>()
        val pending = HashMap<String, Pair<Int, ArrayList<Int>>>() // заголовок → (длина, данные)
        for (line in lines) {
            val tokens = line.trim().split(Regex("\\s+"))
            if (tokens.size < 2) continue
            val bytes = parseHexBytes(line) ?: continue
            if (tokens[0].length != 3) { result.add(bytes); continue } // нет заголовка
            val hdr = tokens[0]
            val pci = bytes[1]
            when (pci shr 4) {
                0 -> {
                    val len = pci and 0x0F
                    if (bytes.size >= 2 + len) result.add(bytes.copyOfRange(2, 2 + len))
                }
                1 -> {
                    if (bytes.size < 3) continue
                    val total = ((pci and 0x0F) shl 8) or bytes[2]
                    val buf = ArrayList<Int>()
                    for (i in 3 until bytes.size) buf.add(bytes[i])
                    pending[hdr] = total to buf
                }
                2 -> {
                    val p = pending[hdr] ?: continue
                    for (i in 2 until bytes.size) p.second.add(bytes[i])
                    if (p.second.size >= p.first) {
                        result.add(p.second.subList(0, p.first).toIntArray())
                        pending.remove(hdr)
                    }
                }
            }
        }
        // недособранные ответы тоже отдаём — вдруг нужные байты уже пришли
        for (p in pending.values) result.add(p.second.toIntArray())
        return result
    }

    /** Данные после положительного ответа: для "010C" ищем "41 0C …", для "2102" — "61 02 …". */
    fun extractData(request: String, lines: List<String>): IntArray? {
        if (request.length < 4) return null
        val sid = request.substring(0, 2).toIntOrNull(16) ?: return null
        val pid = request.substring(2, 4).toIntOrNull(16) ?: return null
        for (msg in reassemble(lines)) {
            for (i in 0 until msg.size - 1) {
                if (msg[i] == sid + 0x40 && msg[i + 1] == pid) return msg.copyOfRange(i + 2, msg.size)
            }
        }
        return null
    }

    /** Два байта кода ошибки → «B1234»: старшие 2 бита — буква P/C/B/U. */
    fun dtcName(hi: Int, lo: Int): String =
        "PCBU"[(hi shr 6) and 3].toString() + String.format("%X%X%02X", (hi shr 4) and 3, hi and 0x0F, lo)

    /** true, если ЭБУ явно отказал (NO DATA, ?, отрицательный ответ 7F). */
    fun isRejected(request: String, lines: List<String>): Boolean {
        if (lines.any { it.contains("NO DATA") || it.trim() == "?" || it.contains("ERROR") }) return true
        val sid = request.substring(0, 2).toIntOrNull(16) ?: return false
        return reassemble(lines).any { m -> m.size >= 2 && m[0] == 0x7F && m[1] == sid }
    }

    fun format(v: Double, decimals: Int): String = String.format(Locale.US, "%.${decimals}f", v)

    private fun a(d: IntArray) = d.getOrNull(0)
    private fun ab(d: IntArray): Int? = if (d.size >= 2) d[0] * 256 + d[1] else null

    /** Стандартные OBD-II (режим 01, широковещательно 7DF) + Pajero Sport II (режим 21). */
    val pollList: List<PollItem> = listOf(
        // ABS Pajero Sport 2008: запрос 0x784, ответ 0x785, таблица 21 20 — скорости колёс.
        // Позиции определены по левому и правому поворотам: D0 ПП, D1 ПЛ, D2 ЗП, D3 ЗЛ.
        // Единицы не км/ч (на 11 км/ч — 7…9), масштаб ещё не откалиброван.
        PollItem(
            "784", "2120", listOf(
                Output("wheel1", "Колесо перед-право (D0)", "ед.") { d -> d.getOrNull(0)?.toDouble() },
                Output("wheel2", "Колесо перед-лево (D1)", "ед.") { d -> d.getOrNull(1)?.toDouble() },
                Output("wheel3", "Колесо зад-право (D2)", "ед.") { d -> d.getOrNull(2)?.toDouble() },
                Output("wheel4", "Колесо зад-лево (D3)", "ед.") { d -> d.getOrNull(3)?.toDouble() },
            )
        ),
        PollItem("7DF", "010C", listOf(Output("010C", "Обороты", "об/мин") { d -> ab(d)?.let { it / 4.0 } })),
        PollItem("7DF", "010D", listOf(Output("010D", "Скорость", "км/ч") { d -> a(d)?.toDouble() })),
        PollItem("7DF", "0105", listOf(Output("0105", "ОЖ", "°C") { d -> a(d)?.let { it - 40.0 } })),
        PollItem("7DF", "010F", listOf(Output("010F", "Впуск", "°C") { d -> a(d)?.let { it - 40.0 } })),
        PollItem("7DF", "010B", listOf(Output("010B", "Давл. впуска (MAP)", "кПа") { d -> a(d)?.toDouble() })),
        PollItem("7DF", "0133", listOf(Output("0133", "Барометр", "кПа") { d -> a(d)?.toDouble() }), every = 10),
        PollItem("7DF", "0111", listOf(Output("0111", "Дроссельная заслонка (дизель: открыта на ХХ)", "%") { d -> a(d)?.let { it * 100.0 / 255 } })),
        PollItem("7DF", "0110", listOf(Output("0110", "Расход воздуха", "г/с", 1) { d -> ab(d)?.let { it / 100.0 } })),
        PollItem("7DF", "0123", listOf(Output("0123", "Давл. в рампе", "МПа", 1) { d -> ab(d)?.let { it * 10.0 / 1000 } })),
        PollItem("7DF", "ATRV", listOf(Output("ATRV", "Напряжение", "В", 1) { null }), every = 3),
        // Pajero Sport II (KH): KWP 0x21, разбор как в igkov/bcomp11.
        // Ответ АКПП: 61 02 A B C D E F G H I … (проверено на KH 2008: F−40 = ATF, G = питание)
        PollItem(
            "7E1", "2102", listOf(
                Output("at_temp", "Масло АКПП (ATF)", "°C") { d -> d.getOrNull(5)?.let { it - 40.0 } },
                Output("at_in", "АКПП вход", "об/мин") { d ->
                    if (d.size >= 3) d[1] * 128.0 + d[2] / 2.0 else null
                },
                Output("at_out", "АКПП выход", "об/мин") { d ->
                    if (d.size >= 5) d[3] * 128.0 + d[4] / 2.0 else null
                },
                Output("at_volt", "АКПП питание соленоидов", "В", 1) { d ->
                    d.getOrNull(6)?.let { it * 33.15 / 255 }
                },
            )
        ),
        // Коррекции форсунок (балансировка цилиндров), найдено на KH 2008: 61 4D A B C D, ноль = 0x80.
        // На ХХ было 7D 7B 7F 88 → −3 −5 −1 +8 (сумма ≈ 0). Единицы и порядок цилиндров не подтверждены.
        PollItem(
            "7E0", "214D", listOf(
                Output("inj1", "Коррекция форсунки 1", "ед.") { d -> d.getOrNull(0)?.let { it - 128.0 } },
                Output("inj2", "Коррекция форсунки 2", "ед.") { d -> d.getOrNull(1)?.let { it - 128.0 } },
                Output("inj3", "Коррекция форсунки 3", "ед.") { d -> d.getOrNull(2)?.let { it - 128.0 } },
                Output("inj4", "Коррекция форсунки 4", "ед.") { d -> d.getOrNull(3)?.let { it - 128.0 } },
            )
        ),
        // Цикловая подача (pajero4x4.ru): 61 4A A B C … → A/2 итоговая, B/2 стартовая, C/2 дымовой предел, мм³/такт
        PollItem(
            "7E0", "214A", listOf(
                Output("fuel_final", "Подача итоговая", "мм³/такт", 1) { d -> d.getOrNull(0)?.let { it / 2.0 } },
                Output("fuel_smoke", "Дымовой предел подачи", "мм³/такт", 1) { d -> d.getOrNull(2)?.let { it / 2.0 } },
            )
        ),
        // Климат (вероятно блок 0x7A2), найдено автопоиском 22.11.2026: 61 10 A B C D E.
        // C — уличный датчик (0x64 при 0 °C; грели — стало 0x6F и остывало). Шаг пока не подтверждён: x−100 или (x−100)/2.
        // D — похоже на салон: 0x29→0x2D после пуска, X−40.
        PollItem(
            "7A2", "2110", listOf(
                Output("amb", "Улица (предв., x−100)", "°C") { d -> d.getOrNull(2)?.let { it - 100.0 } },
                Output("amb_raw", "Улица, сырое значение", "") { d -> d.getOrNull(2)?.toDouble() },
                Output("cabin", "Салон (предв., x−40)", "°C") { d -> d.getOrNull(3)?.let { it - 40.0 } },
            ), every = 5
        ),
        // Пробег из ЭБУ двигателя: 61 03 A B C D → B·65536 + C·256 + D км
        PollItem(
            "7E0", "2103", listOf(
                Output("odo", "Пробег по ЭБУ двигателя (≠ одометр)", "км") { d ->
                    if (d.size >= 4) (d[1] * 65536 + d[2] * 256 + d[3]).toDouble() else null
                },
            ), every = 20
        ),
    )
}
