plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.diy.elmcan"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.diy.elmcan"
        minSdk = 24
        targetSdk = 34
        versionCode = 11
        versionName = "2.0"
    }

    // Постоянный ключ подписи: обновления ставятся поверх, без удаления приложения.
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
// Внешних библиотек нет — только Android SDK и Kotlin stdlib.
